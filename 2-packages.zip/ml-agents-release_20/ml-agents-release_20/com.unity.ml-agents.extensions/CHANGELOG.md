# Changelog
This changelog isn't used; please add to the `com.unity.ml-agents` changelog instead.

## [0.6.1-preview]
 * Initial version
