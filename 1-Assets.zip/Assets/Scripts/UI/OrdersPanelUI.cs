using System;
using System.Collections.Generic;
using System.Linq;
using Undercooked.Managers;
using Undercooked.Model;
using UnityEngine;
using UnityEngine.Assertions;

namespace Undercooked.UI
{
    public class OrdersPanelUI : MonoBehaviour
    {
        [SerializeField] private OrderUI orderUIPrefab;
        public readonly List<OrderUI> _ordersUI = new List<OrderUI>();
        public readonly Queue<OrderUI> _orderUIPool = new Queue<OrderUI>();

        private void Awake()
        {
            #if UNITY_EDITOR
                Assert.IsNotNull(orderUIPrefab);
            #endif
        }

        private OrderUI GetOrderUIFromPool()
        {
            //  return _orderUIPool.Count > 0 ? _orderUIPool.Dequeue() : Instantiate(orderUIPrefab, transform);

            OrderUI orderUI = _orderUIPool.Count > 0 ? _orderUIPool.Dequeue() : Instantiate(orderUIPrefab, transform);
            orderUI.gameObject.SetActive(true); // Make sure the object is active
            return orderUI;
        }
        
        private void OnEnable()
        {
            OrderManager.OnOrderSpawned += HandleOrderSpawned;
        }

        private void OnDisable()
        {
            OrderManager.OnOrderSpawned -= HandleOrderSpawned;
        }

        private void HandleOrderSpawned(Order order)
        {
            var rightmostX = GetRightmostXFromLastElement();
            var orderUI = GetOrderUIFromPool();
            orderUI.Setup(order);
            _ordersUI.Add(orderUI);
            orderUI.SlideInSpawn(rightmostX);

        }

        private float GetRightmostXFromLastElement()
        {
            if (_ordersUI.Count == 0) return 0;
            
            float rightmostX = 0f;
            
            List<OrderUI> orderUisNotDeliveredOrderedByLeftToRight = _ordersUI
                .Where(x => x.Order.IsDelivered == false)
                .OrderBy(y => y.CurrentAnchorX).ToList();

            if (orderUisNotDeliveredOrderedByLeftToRight.Count == 0) return 0;
            
            var last = orderUisNotDeliveredOrderedByLeftToRight.Last();
            rightmostX = last.CurrentAnchorX + last.SizeDeltaX;

            return rightmostX;
        }
        public void RegroupPanelsLeft()
        {
            float leftmostX = 0f;
            List<OrderUI> toRemove = new List<OrderUI>();

            foreach (var orderUI in _ordersUI)
            {
                if (orderUI.Order.IsDelivered)
                {
                    _orderUIPool.Enqueue(orderUI);
                    toRemove.Add(orderUI);
                }
                else
                {
                    orderUI.SlideLeft(leftmostX);
                    leftmostX += orderUI.SizeDeltaX;
                }
            }

            foreach (var orderUI in toRemove)
            {
                _ordersUI.Remove(orderUI);
            }
        }

        /*
        public void RegroupPanelsLeft()
        {
            float leftmostX = 0f;

            for (var i = 0; i < _ordersUI.Count; i++)
            {
                var orderUI = _ordersUI[i];
                if (orderUI.Order.IsDelivered)
                {
                    _orderUIPool.Enqueue(orderUI);
                    _ordersUI.RemoveAt(i);
                    i--;
                }
                else
                {
                    orderUI.SlideLeft(leftmostX);
                    leftmostX += orderUI.SizeDeltaX;
                }
            }
        }
        */
        

        // NEEDED FOR COOKER AGENT EPISODES
     
        public void ClearOrdersUI()
        {
            foreach (Transform child in transform) // Assuming OrderUI instances are children of the OrdersPanelUI GameObject
            {
                Destroy(child.gameObject); // Or use a pooling system to deactivate instead of destroy
            }
            _ordersUI.Clear(); // Clear the list of OrderUI references
            _orderUIPool.Clear(); // Clear the pool of OrderUI references
        }

        public void SetupNewEpisodeOrders(List<Order> newOrders)
        {
            ClearOrdersUI(); // Clear existing UIs
            foreach (var order in newOrders)
            {
                var orderUI = Instantiate(orderUIPrefab, transform); // Assuming you have an OrderUI prefab
                orderUI.Setup(order); // Set up the new OrderUI with the order details
            }
        }
     
    }
}
