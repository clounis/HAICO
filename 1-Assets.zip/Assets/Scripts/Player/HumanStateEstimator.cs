/*
using System.Collections;
using Lean.Transition;
using Undercooked.Appliances;
using Undercooked.Model;
using Undercooked.UI;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Undercooked.Player
{
    public class HumanStateEstimator : MonoBehaviour
    {
        private PlayerController _playerController;

        private void Start()
        {
            _playerController = GetComponent<PlayerController>();
            StartCoroutine(EstimateHumanState());
        }

        private IEnumerator EstimateHumanState()
        {
            while (true)
            {
                if (_playerController.IsChopping())
                {
                    Debug.Log("Human is chopping");
                    // Do something when the human is chopping
                }
                else if (_playerController.IsCarrying())
                {
                    Debug.Log("Human is carrying");
                    // Do something when the human is carrying something
                }
                else if (_playerController.IsCleaning())
                {
                    Debug.Log("Human is cleaning");
                    // Do something when the human is cleaning
                }
                else
                {
                    Debug.Log("Human is idle");
                    // Do something when the human is idle
                }

                yield return new WaitForSeconds(1.0f); // Adjust the interval as needed
            }
        }
    }
}
*/