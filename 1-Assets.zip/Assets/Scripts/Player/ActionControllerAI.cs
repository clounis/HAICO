/*using System.Collections;
using Lean.Transition;
using Undercooked.Appliances;
using Undercooked.Model;
using Undercooked.UI;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.InputSystem;

namespace Undercooked.Player
{
    public class ActionControllerAI : MonoBehaviour
    {
        [SerializeField] private Color playerColor;
        [SerializeField] private Transform selector;
        [SerializeField] private Material playerUniqueColorMaterial;

        [Header("Physics")]
        [SerializeField] private Rigidbody playerRigidbody;

        [Header("Animation")]
        [SerializeField] private Animator animator;
        private readonly int _isCleaningHash = Animator.StringToHash("isCleaning");
        private readonly int _hasPickupHash = Animator.StringToHash("hasPickup");
        private readonly int _isChoppingHash = Animator.StringToHash("isChopping");

        [Header("Input")]
        [SerializeField] private PlayerInput playerInput;
        public InputAction _pickUpAction;
        private InputAction _interactAction;
        private InputAction _startAtPlayerAction;

     

        [Header("Movement Settings")]
        [SerializeField] private float movementSpeed = 5f;

        private InteractableController _interactableController;
        private bool _isActive;
        public IPickable _currentPickable;
        private Vector3 _inputDirection;
        private bool _hasSubscribedControllerEvents;

        [SerializeField] private Transform slot;
        [SerializeField] private Transform knife;

        [Header("Audio")]
        [SerializeField] private AudioClip dashAudio;
        [SerializeField] private AudioClip pickupAudio;
        [SerializeField] private AudioClip dropAudio;

        //FOR AGENT RESET:
        private Vector3 initialPosition;
        private Quaternion initialRotation;


        public void ClearAgentSlot()
        {
            if (slot.childCount > 0)
            {
                var ingredient = slot.GetChild(0).GetComponent<Ingredient>();
                if (ingredient != null)
                {
                    // Optionally, do something with the ingredient before destroying
                    // e.g., return it to a pool or set some state
                    Destroy(ingredient.gameObject); // Destroy the ingredient object
                }
                _currentPickable = null; // Clear the reference if using _currentPickable to track the held item
            }
            // Reset the agent's position and rotation to its initial state
            transform.position = initialPosition;
            transform.rotation = initialRotation;
        }


        private void Awake()
        {
            //FOR AGENT RESET
            // Store the initial position and rotation for later use
            initialPosition = transform.position;
            initialRotation = transform.rotation;

            _pickUpAction = playerInput.currentActionMap["PickUp"];
            _interactAction = playerInput.currentActionMap["Interact"];
            _startAtPlayerAction = playerInput.currentActionMap["Start@Player"];

            _interactableController = GetComponentInChildren<InteractableController>();
            knife.gameObject.SetActive(false);
        }

        private void OnEnable()
        {
            SubscribeInteractableEvents();
        }

        private void OnDisable()
        {
            UnsubscribeInteractableEvents();
        }

        private void SubscribeControllerEvents()
        {
            if (_hasSubscribedControllerEvents) return;
            _hasSubscribedControllerEvents = true;
            _pickUpAction.performed += HandlePickUp;
            _interactAction.performed += HandleInteract;
        }

        private void UnsubscribeControllerEvents()
        {
            if (_hasSubscribedControllerEvents == false) return;

            _hasSubscribedControllerEvents = false;
            _pickUpAction.performed -= HandlePickUp;
            _interactAction.performed -= HandleInteract;
        }

        private void SubscribeInteractableEvents()
        {
            ChoppingBoard.OnChoppingStart += HandleChoppingStart;
            ChoppingBoard.OnChoppingStop += HandleChoppingStop;
            Sink.OnCleanStart += HandleCleanStart;
            Sink.OnCleanStop += HandleCleanStop;
        }

        private void UnsubscribeInteractableEvents()
        {
            ChoppingBoard.OnChoppingStart -= HandleChoppingStart;
            ChoppingBoard.OnChoppingStop -= HandleChoppingStop;
            Sink.OnCleanStart -= HandleCleanStart;
            Sink.OnCleanStop -= HandleCleanStop;
        }

        private void HandleCleanStart(PlayerController playerController)
        {
            if (Equals(playerController) == false) return;

            animator.SetBool(_isCleaningHash, true);
        }

        private void HandleCleanStop(PlayerController playerController)
        {
            if (Equals(playerController) == false) return;

            animator.SetBool(_isCleaningHash, false);
        }

        private void HandleChoppingStart(PlayerController playerController)
        {
            if (Equals(playerController) == false) return;

            animator.SetBool(_isChoppingHash, true);
            knife.gameObject.SetActive(true);
        }

        private void HandleChoppingStop(PlayerController playerController)
        {
            if (Equals(playerController) == false) return;

            animator.SetBool(_isChoppingHash, false);
            knife.gameObject.SetActive(false);
        }

      
   
        private void HandlePickUp(InputAction.CallbackContext context)
        {
            var interactable = _interactableController.CurrentInteractable;

            // empty hands, try to pick
            if (_currentPickable == null)
            {
                _currentPickable = interactable as IPickable;
                if (_currentPickable != null)
                {
                    animator.SetBool(_hasPickupHash, true);
                    this.PlaySoundTransition(pickupAudio);
                    _currentPickable.Pick();
                    _interactableController.Remove(_currentPickable as Interactable);
                    _currentPickable.gameObject.transform.SetPositionAndRotation(slot.transform.position,
                        Quaternion.identity);
                    _currentPickable.gameObject.transform.SetParent(slot);
                    return;
                }


                // Interactable only (not a IPickable)
                _currentPickable = interactable?.TryToPickUpFromSlot(_currentPickable);
                if (_currentPickable != null)
                {
                    animator.SetBool(_hasPickupHash, true);
                    this.PlaySoundTransition(pickupAudio);
                }

                _currentPickable?.gameObject.transform.SetPositionAndRotation(
                    slot.position, Quaternion.identity);
                _currentPickable?.gameObject.transform.SetParent(slot);
                return;
            }

            // we carry a pickable, let's try to drop it (we may fail)

            // no interactable in range or at most a Pickable in range (we ignore it)
            if (interactable == null || interactable is IPickable)
            {
                animator.SetBool(_hasPickupHash, false);
                this.PlaySoundTransition(dropAudio);
                _currentPickable.Drop();
                _currentPickable = null;
                return;
            }

            // we carry a pickable and we have an interactable in range
            // we may drop into the interactable

            // Try to drop on the interactable. It may refuse it, e.g. dropping a plate into the CuttingBoard,
            // or simply it already have something on it
            //Debug.Log($"[PlayerController] {_currentPickable.gameObject.name} trying to drop into {interactable.gameObject.name} ");

            bool dropSuccess = interactable.TryToDropIntoSlot(_currentPickable);
            if (!dropSuccess) return;

            animator.SetBool(_hasPickupHash, false);
            this.PlaySoundTransition(dropAudio);
            _currentPickable = null;
        }


        private void HandleInteract(InputAction.CallbackContext context)
        {
            _interactableController.CurrentInteractable?.Interact(this);
        }


        public void Drop()
        {
            // Check if the player is holding an item
            if (_currentPickable != null)
            {
                // Play drop audio
                this.PlaySoundTransition(dropAudio);

                // Remove the pickable item from the player's "slot" and reset its position
                // You might want to define a specific drop position based on the player's current position and facing direction
                Vector3 dropPosition = transform.position + transform.forward * 1.0f; // Adjust multiplier as needed

                // Update animator state
                animator.SetBool(_hasPickupHash, false);

                // Update the item's position in the game world to the drop position
                _currentPickable.gameObject.transform.position = dropPosition;

                // Call Drop method on the pickable item to trigger any other necessary logic
                _currentPickable.Drop();

                // Clear the reference to the current pickable item
                _currentPickable = null;
            }
        }

        public IPickable CurrentPickable
        {
            get { return _currentPickable; }
        }
    }
}
*/