using System.Collections;
using Lean.Transition;
using Undercooked.Appliances;
using Undercooked.Model;
using Undercooked.UI;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.InputSystem;

namespace Undercooked.Player
{
    public class PlayerController : MonoBehaviour
    {
        [SerializeField] private Color playerColor;
        [SerializeField] private Transform selector;
        [SerializeField] private Material playerUniqueColorMaterial;

        [Header("Physics")]
        [SerializeField] private Rigidbody playerRigidbody;

        [Header("Animation")]
        [SerializeField] private Animator animator;
        private readonly int _isCleaningHash = Animator.StringToHash("isCleaning");
        private readonly int _hasPickupHash = Animator.StringToHash("hasPickup");
        private readonly int _isChoppingHash = Animator.StringToHash("isChopping");
        private readonly int _velocityHash = Animator.StringToHash("velocity");

        [Header("Input")]
        [SerializeField] private PlayerInput playerInput;
        private InputAction _moveAction;
        private InputAction _dashAction;
        public InputAction _pickUpAction;
        private InputAction _interactAction;
        private InputAction _startAtPlayerAction;

        // Dashing
        [SerializeField] private float dashForce = 900f;
        private bool _isDashing = false;
        private bool _isDashingPossible = true;
        private readonly WaitForSeconds _dashDuration = new WaitForSeconds(0.17f);
        private readonly WaitForSeconds _dashCooldown = new WaitForSeconds(0.07f);

        [Header("Movement Settings")]
        [SerializeField] private float movementSpeed = 5f;

        private InteractableController _interactableController;
        private bool _isActive;
        public IPickable _currentPickable;
        private Vector3 _inputDirection;
        private bool _hasSubscribedControllerEvents;

        [SerializeField] private Transform slot;
        [SerializeField] private ParticleSystem dashParticle;
        [SerializeField] private Transform knife;

        [Header("Audio")]
        [SerializeField] private AudioClip dashAudio;
        [SerializeField] private AudioClip pickupAudio;
        [SerializeField] private AudioClip dropAudio;

        //FOR AGENT RESET:
        private Vector3 initialPosition;
        private Quaternion initialRotation;


        // FOR AGENT RESET
        /*  public void AgentReset()
          {
              // Clear the slot if it contains any items
              if (slot.childCount > 0)
              {
                  for (int i = slot.childCount - 1; i >= 0; i--)
                  {
                      var child = slot.GetChild(i);
                      // Optional: Check if the child is an ingredient and perform specific actions
                      // For example, return it to its original position or destroy it
                      Destroy(child.gameObject);
                  }
              }



              // Reset NavMeshAgent's path if necessary
             // if (navMeshAgent != null)
              //{
               //   navMeshAgent.ResetPath();
             // }

              // Reset any other state specific to the agent
              // For example, reset internal counters, flags, etc.
          }*/
        public void ClearAgentSlot()
        {
        

         if (_currentPickable != null)
            {
                
                _currentPickable.Drop();  // Reset any specific state on the pickable
                _currentPickable.gameObject.transform.SetParent(null);  // Detach from player
                _currentPickable = null;  // Clear the reference
            }
         
            
             if (slot.childCount > 0)
            {
                var ingredient = slot.GetChild(0).GetComponent<Ingredient>();
                if (ingredient != null)
                {
                    // Optionally, do something with the ingredient before destroying
                    // e.g., return it to a pool or set some state
                    Destroy(ingredient.gameObject); // Destroy the ingredient object
                }
                _currentPickable = null; // Clear the reference if using _currentPickable to track the held item
            }
            

            // Reset the agent's position and rotation to its initial state
            if (animator != null)
            {
                animator.SetBool(_hasPickupHash, false); // Reset animation state
            }
            // Reset the agent's position and rotation to its initial state
            transform.position = initialPosition;
            transform.rotation = initialRotation;

        }


        private void Awake()
        {
            //FOR AGENT RESET
            // Store the initial position and rotation for later use
            initialPosition = transform.position;
            initialRotation = transform.rotation;

            _moveAction = playerInput.currentActionMap["Move"];
            _dashAction = playerInput.currentActionMap["Dash"];
            _pickUpAction = playerInput.currentActionMap["PickUp"];
            _interactAction = playerInput.currentActionMap["Interact"];
            _startAtPlayerAction = playerInput.currentActionMap["Start@Player"];

            _interactableController = GetComponentInChildren<InteractableController>();
            knife.gameObject.SetActive(false);

            SetPlayerUniqueColor(playerColor);
        }

        private void SetPlayerUniqueColor(Color color)
        {
            selector.GetComponent<MeshRenderer>().material.color = color;
            playerUniqueColorMaterial.color = color;
        }

        public void ActivatePlayer()
        {
            _isActive = true;
            SubscribeControllerEvents();
            selector.gameObject.SetActive(true);
        }

        public void DeactivatePlayer()
        {
            _isActive = false;
            UnsubscribeControllerEvents();
            animator.SetFloat(_velocityHash, 0f);
            selector.gameObject.SetActive(false);
        }

        private void OnEnable()
        {
            SubscribeInteractableEvents();
        }

        private void OnDisable()
        {
            UnsubscribeInteractableEvents();
        }

        private void SubscribeControllerEvents()
        {
            if (_hasSubscribedControllerEvents) return;
            _hasSubscribedControllerEvents = true;
            _moveAction.performed += HandleMove;
            _dashAction.performed += HandleDash;
            _pickUpAction.performed += HandlePickUp;
            _interactAction.performed += HandleInteract;
        }

        private void UnsubscribeControllerEvents()
        {
            if (_hasSubscribedControllerEvents == false) return;

            _hasSubscribedControllerEvents = false;
            _moveAction.performed -= HandleMove;
            _dashAction.performed -= HandleDash;
            _pickUpAction.performed -= HandlePickUp;
            _interactAction.performed -= HandleInteract;
        }

        private void SubscribeInteractableEvents()
        {
            ChoppingBoard.OnChoppingStart += HandleChoppingStart;
            ChoppingBoard.OnChoppingStop += HandleChoppingStop;
            Sink.OnCleanStart += HandleCleanStart;
            Sink.OnCleanStop += HandleCleanStop;
        }

        private void UnsubscribeInteractableEvents()
        {
            ChoppingBoard.OnChoppingStart -= HandleChoppingStart;
            ChoppingBoard.OnChoppingStop -= HandleChoppingStop;
            Sink.OnCleanStart -= HandleCleanStart;
            Sink.OnCleanStop -= HandleCleanStop;
        }

        public void HandleCleanStart(PlayerController playerController)
        {
            //            if (Equals(playerController) == false) return;
            // Check if the event is meant for this instance
            if (this != playerController) return;

            animator.SetBool(_isCleaningHash, true);
        }

        public void HandleCleanStop(PlayerController playerController)
        {
            // if (Equals(playerController) == false) return;

            // Check if the event is meant for this instance
            if (this != playerController) return;

            animator.SetBool(_isCleaningHash, false);
        }

        public void HandleCleanstart(PlayerController playerController)
        {
            if (playerController == this)
            {
                StartCleaning();
            }
        }

        public void HandleCleanstop(PlayerController playerController)
        {
            if (playerController == this)
            {
                StopCleaning();
            }
        }
        
        public void StartCleaning()
   {
       // Core logic to start cleaning
       animator.SetBool(_isCleaningHash, true);
       // Any other necessary logic...
   }

   public void StopCleaning()
   {
       // Core logic to stop cleaning
       animator.SetBool(_isCleaningHash, false);
       // Any other necessary logic...
   }

  //COPY FOR COOKER AGENT







       public void StartChopping()
   {
       // Core logic to start chopping
       animator.SetBool(_isChoppingHash, true);
       knife.gameObject.SetActive(true);
       // Any other necessary logic...
   }

   public void StopChopping()
   {
       // Core logic to stop chopping
       animator.SetBool(_isChoppingHash, false);
       knife.gameObject.SetActive(false);
       // Any other necessary logic...
   }

   public void HandleChoppingstart(PlayerController playerController)
   {
       if (playerController == this)
       {
           StartChopping();
       }
   }

   public void HandleChoppingstop(PlayerController playerController)
   {
       if (playerController == this)
       {
           StopChopping();
       }
   }
  
        // END FOR COOKER AGENT

        public void HandleChoppingStart(PlayerController playerController)
        {
            //if (Equals(playerController) == false) return;

            // Check if the event is meant for this instance
            if (this != playerController) return;


            animator.SetBool(_isChoppingHash, true);
            knife.gameObject.SetActive(true);
        }

        public void HandleChoppingStop(PlayerController playerController)
        {
            // if (Equals(playerController) == false) return;

            // Check if the event is meant for this instance
            if (this != playerController) return;

            animator.SetBool(_isChoppingHash, false);
            knife.gameObject.SetActive(false);
        }

        private void HandleDash(InputAction.CallbackContext context)
        {
            if (!_isDashingPossible) return;
            StartCoroutine(Dash());
        }

        private IEnumerator Dash()
        {
            _isDashingPossible = false;
            playerRigidbody.AddRelativeForce(dashForce * Vector3.forward);
            //dashParticle.Play();
            dashParticle.PlaySoundTransition(dashAudio);

            yield return new WaitForFixedUpdate();
            _isDashing = true;
            yield return _dashDuration;
            _isDashing = false;
            yield return _dashCooldown;
            _isDashingPossible = true;
        }

        public void HandlePickUpExternally()
        {
            var interactable = _interactableController.CurrentInteractable;

            // empty hands, try to pick
            if (_currentPickable == null)
            {
                _currentPickable = interactable as IPickable;
                if (_currentPickable != null)
                {
                    animator.SetBool(_hasPickupHash, true);
                    this.PlaySoundTransition(pickupAudio);
                    _currentPickable.Pick();
                    _interactableController.Remove(_currentPickable as Interactable);
                    _currentPickable.gameObject.transform.SetPositionAndRotation(slot.transform.position,
                        Quaternion.identity);
                    _currentPickable.gameObject.transform.SetParent(slot);
                    return;
                }


                // Interactable only (not a IPickable)
                _currentPickable = interactable?.TryToPickUpFromSlot(_currentPickable);
                if (_currentPickable != null)
                {
                    animator.SetBool(_hasPickupHash, true);
                    this.PlaySoundTransition(pickupAudio);
                }

                _currentPickable?.gameObject.transform.SetPositionAndRotation(
                    slot.position, Quaternion.identity);
                _currentPickable?.gameObject.transform.SetParent(slot);
                return;
            }

            // we carry a pickable, let's try to drop it (we may fail)

            // no interactable in range or at most a Pickable in range (we ignore it)
            if (interactable == null || interactable is IPickable)
            {
                animator.SetBool(_hasPickupHash, false);
                this.PlaySoundTransition(dropAudio);
                _currentPickable.Drop();
                _currentPickable = null;
                return;
            }

            // we carry a pickable and we have an interactable in range
            // we may drop into the interactable

            // Try to drop on the interactable. It may refuse it, e.g. dropping a plate into the CuttingBoard,
            // or simply it already have something on it
           // Debug.Log($"[PlayerController] {_currentPickable.gameObject.name} trying to drop into {interactable.gameObject.name} ");

            bool dropSuccess = interactable.TryToDropIntoSlot(_currentPickable);
            if (!dropSuccess) return;

            animator.SetBool(_hasPickupHash, false);
            this.PlaySoundTransition(dropAudio);
            _currentPickable = null;
        }

        /* public void InteractWith(Interactable interactableAgent)
         {
             // Determine the type of interaction based on the interactable object
             if (interactableAgent is ChoppingBoard)
             {
                 StartChopping();
                 // Optionally, directly call choppingBoard.Interact(this) if more specific interaction is needed
             }
             else if (interactableAgent is Sink)
             {
                 StartCleaning();
                 // Optionally, directly call sink.Interact(this) if more specific interaction is needed
             }
             // Add more conditions here for different types of interactables
             else
             {
                 Debug.Log("Interactable type not supported for direct interaction.");
             }
         }
        */
        /* private void HandleInteractAgent(InputAction.CallbackContext context)
         {
             // Call InteractWith method if there is an interactable object
             var interactableAgent = _interactableController.CurrentInteractable;
             if (interactableAgent != null)
             {
                 InteractWith(interactableAgent);
             }
         }
        */
        /*
        public void InteractWith(Interactable interactable)
        {
            if (interactable is ChoppingBoard choppingBoard)
            {
                // Logic to interact with chopping board
                StartChopping(); // or choppingBoard.Interact(this);
            }
            else if (interactable is Sink sink)
            {
                // Logic to interact with sink
                StartCleaning(); // or sink.Interact(this);
            }
            // Handle other interactable types similarly
        }

        public void HandleInteractAI()
        {
            var interactable = _interactableController.CurrentInteractable;
            if (interactable != null)
            {
                InteractWith(interactable);
            }
        }
        */


        public void HandlePickUp(InputAction.CallbackContext context)
        {
            var interactable = _interactableController.CurrentInteractable;

            // empty hands, try to pick
            if (_currentPickable == null)
            {
                _currentPickable = interactable as IPickable;
                if (_currentPickable != null)
                {
                    animator.SetBool(_hasPickupHash, true);
                    this.PlaySoundTransition(pickupAudio);
                    _currentPickable.Pick();
                    _interactableController.Remove(_currentPickable as Interactable);
                    _currentPickable.gameObject.transform.SetPositionAndRotation(slot.transform.position,
                        Quaternion.identity);
                    _currentPickable.gameObject.transform.SetParent(slot);
                    return;
                }


                // Interactable only (not a IPickable)
                _currentPickable = interactable?.TryToPickUpFromSlot(_currentPickable);
                if (_currentPickable != null)
                {
                    animator.SetBool(_hasPickupHash, true);
                    this.PlaySoundTransition(pickupAudio);
                }

                _currentPickable?.gameObject.transform.SetPositionAndRotation(
                    slot.position, Quaternion.identity);
                _currentPickable?.gameObject.transform.SetParent(slot);
                return;
            }

            // we carry a pickable, let's try to drop it (we may fail)

            // no interactable in range or at most a Pickable in range (we ignore it)
            if (interactable == null || interactable is IPickable)
            {
                animator.SetBool(_hasPickupHash, false);
                this.PlaySoundTransition(dropAudio);
                _currentPickable.Drop();
                _currentPickable = null;
                return;
            }

            // we carry a pickable and we have an interactable in range
            // we may drop into the interactable

            // Try to drop on the interactable. It may refuse it, e.g. dropping a plate into the CuttingBoard,
            // or simply it already have something on it
            //Debug.Log($"[PlayerController] {_currentPickable.gameObject.name} trying to drop into {interactable.gameObject.name} ");

            bool dropSuccess = interactable.TryToDropIntoSlot(_currentPickable);
            if (!dropSuccess) return;

            animator.SetBool(_hasPickupHash, false);
            this.PlaySoundTransition(dropAudio);
            _currentPickable = null;
        }



        private void HandleMove(InputAction.CallbackContext context)
        {
            // TODO: Processors on input binding not working for analogical stick. Investigate it.
            Vector2 inputMovement = context.ReadValue<Vector2>();
            if (inputMovement.x > 0.3f)
            {
                inputMovement.x = 1f;
            }
            else if (inputMovement.x < -0.3)
            {
                inputMovement.x = -1f;
            }
            else
            {
                inputMovement.x = 0f;
            }

            if (inputMovement.y > 0.3f)
            {
                inputMovement.y = 1f;
            }
            else if (inputMovement.y < -0.3f)
            {
                inputMovement.y = -1f;
            }
            else
            {
                inputMovement.y = 0f;
            }

            _inputDirection = new Vector3(inputMovement.x, 0, inputMovement.y);
        }

        private void HandleInteract(InputAction.CallbackContext context)
        {
            _interactableController.CurrentInteractable?.Interact(this);
        }

        private void HandleStart(InputAction.CallbackContext context)
        {
            MenuPanelUI.PauseUnpause();
        }

        private void Update()
        {
            if (!_isActive) return;
            CalculateInputDirection();
        }

        private void FixedUpdate()
        {
            if (!_isActive) return;
            MoveThePlayer();
            AnimatePlayerMovement();
            TurnThePlayer();
        }

        private void MoveThePlayer()
        {
            if (_isDashing)
            {
                var currentVelocity = playerRigidbody.velocity.magnitude;

                var inputNormalized = _inputDirection.normalized;
                if (inputNormalized == Vector3.zero)
                {
                    inputNormalized = transform.forward;
                }

                playerRigidbody.velocity = inputNormalized * currentVelocity;
            }
            else
            {
                playerRigidbody.velocity = _inputDirection.normalized * movementSpeed;
            }
        }

        private void CalculateInputDirection()
        {
            var inputMovement = _moveAction.ReadValue<Vector2>();
            if (inputMovement.x > 0.3f)
            {
                inputMovement.x = 1f;
            }
            else if (inputMovement.x < -0.3)
            {
                inputMovement.x = -1f;
            }
            else
            {
                inputMovement.x = 0f;
            }

            if (inputMovement.y > 0.3f)
            {
                inputMovement.y = 1f;
            }
            else if (inputMovement.y < -0.3f)
            {
                inputMovement.y = -1f;
            }
            else
            {
                inputMovement.y = 0f;
            }

            _inputDirection = new Vector3(inputMovement.x, 0f, inputMovement.y);
        }

        private void TurnThePlayer()
        {
            if (!(playerRigidbody.velocity.magnitude > 0.1f) || _inputDirection == Vector3.zero) return;

            Quaternion newRotation = Quaternion.LookRotation(_inputDirection);
            transform.rotation = Quaternion.Slerp(transform.rotation, newRotation, Time.deltaTime * 15f);
        }

        private void AnimatePlayerMovement()
        {
            animator.SetFloat(_velocityHash, _inputDirection.sqrMagnitude);
        }

        /*
        public void Drop()
        {
            // Check if the player is holding an item
            if (_currentPickable != null)
            {
                // Play drop audio
                this.PlaySoundTransition(dropAudio);

                // Remove the pickable item from the player's "slot" and reset its position
                // You might want to define a specific drop position based on the player's current position and facing direction
                Vector3 dropPosition = transform.position + transform.forward * 1.0f; // Adjust multiplier as needed

                // Update animator state
                animator.SetBool(_hasPickupHash, false);

                // Update the item's position in the game world to the drop position
                _currentPickable.gameObject.transform.position = dropPosition;

                // Call Drop method on the pickable item to trigger any other necessary logic
                _currentPickable.Drop();

                // Clear the reference to the current pickable item
                _currentPickable = null;
            }
        }
        */
        /*    public void PickUp(IPickable pickableItem)
            {
                // Implement logic to pick up an item
                // For instance, you could set a variable to hold the reference to the picked-up item.
                if (_currentPickable == null)
                {
                    _currentPickable = pickableItem;
                    // You might also want to update the item's position to indicate it's being held, 
                    // and potentially trigger any other necessary logic for when an item is picked up.
                }
                else
                {
                    // Logic for when the player is already holding an item could go here,
                    // such as not allowing the pick-up to happen and potentially giving feedback to the player.
                }
            }
        */
        public IPickable CurrentPickable
        {
            get { return _currentPickable; }
        }
    }
}
