/*
using UnityEngine;
using Undercooked.Model;
using Undercooked.Appliances;
using Undercooked.UI;
using System.Collections;

namespace Undercooked.Player
{
    public class PlayerAIController : MonoBehaviour
    {
        [SerializeField] private InteractableController interactableController;
        [SerializeField] private Transform slot;
        [SerializeField] private Animator animator;
        // Assuming a mechanism to track AI's current state and decision making, not detailed here.

        private IPickable _currentPickable;

        private void Awake()
        {
            interactableController = GetComponentInChildren<InteractableController>();
            animator = GetComponent<Animator>();
        }

        public void PickUp()
        {
            var interactable = interactableController.TryGetClosestInteractable();
            if (interactable is IPickable pickable && _currentPickable == null)
            {
                _currentPickable = pickable;
                _currentPickable.Pick();
                AttachToSlot(_currentPickable.gameObject);
                animator.SetBool("hasPickup", true); // Assuming "hasPickup" is the animation trigger for picking up
            }
        }

        public void Drop()
        {
            if (_currentPickable != null)
            {
                _currentPickable.Drop();
                _currentPickable = null;
                animator.SetBool("hasPickup", false); // Assuming "hasPickup" is the animation trigger for dropping
            }
        }

        public void Chop()
        {
            // Assume the AI knows which chopping board it wants to interact with.
            // This could be determined by the AI's decision-making logic.
            var choppingBoard = interactableController.TryGetClosestInteractable() as ChoppingBoard;
            if (choppingBoard != null && _currentPickable is Ingredient ingredient)
            {
                StartCoroutine(ChopCoroutine(choppingBoard, ingredient));
            }
        }

        public void Clean()
        {
            // Similar to Chop, assume the AI decides when and what to clean.
            var sink = interactableController.TryGetClosestInteractable() as Sink;
            if (sink != null && _currentPickable is Plate plate)
            {
                StartCoroutine(CleanCoroutine(sink, plate));
            }
        }

        private IEnumerator ChopCoroutine(ChoppingBoard choppingBoard, Ingredient ingredient)
        {
            animator.SetBool("isChopping", true);
            yield return new WaitForSeconds(choppingBoard.GetProcessTime()); // Simulate chopping time
            ingredient.Process(); // Assume Ingredient has a method to mark it as processed
            animator.SetBool("isChopping", false);
        }

        private IEnumerator CleanCoroutine(Sink sink, Plate plate)
        {
            animator.SetBool("isCleaning", true);
            yield return new WaitForSeconds(sink.GetCleaningTime()); // Simulate cleaning time
            plate.Clean(); // Assume Plate has a method to mark it as clean
            animator.SetBool("isCleaning", false);
        }

        private void AttachToSlot(GameObject item)
        {
            item.transform.SetParent(slot, false);
            item.transform.localPosition = Vector3.zero;
            item.transform.localRotation = Quaternion.identity;
        }
    }
}
*/