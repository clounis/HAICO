using Undercooked.Appliances;
using Undercooked.Model;
using UnityEngine;

public interface InteractionBase
{
    void Interact(InteractionBase interactor);
    void InteractWith(InteractionBase interactor);

}