using Undercooked.Model;
using UnityEngine;
using UnityEngine.Assertions;
using Undercooked.Player;
using Undercooked.Appliances;

public class DistanceCalculator : MonoBehaviour
{
    public GameObject Artificial_Agent;
    public GameObject IngredientCrate_Tomato;
    public GameObject IngredientCrate_Onion;
    public GameObject IngredientCrate_Mushroom;
    public GameObject IngredientCrate_Tomato_01;
    public GameObject IngredientCrate_Onion_01;
    public GameObject IngredientCrate_Mushroom_01;
    public GameObject Sink;
    public GameObject ChoppingBoard_Countetop1;
    public GameObject ChoppingBoard_Countetop2;
    public GameObject Hob;
    public GameObject Trash;
    public GameObject DeliverCountertop;
    public GameObject Human_Agent;
    public GameObject Plate_2;
    public GameObject Plate_3;
    ///public GameObject Plate;
    //public GameObject Plate_01;

    private void Update()
    {
        // R�cup�rer la position de l'agent Artificiel qui doit �tre update car en d�placement
        GameObject artificialAgent = Artificial_Agent;
        GameObject humanAgent = Human_Agent; 

        // V�rifier si les objets ont �t� trouv�s
              if (artificialAgent != null && IngredientCrate_Tomato != null && IngredientCrate_Onion != null)
        /*
        if (artificialAgent != null && IngredientCrate_Tomato != null && IngredientCrate_Onion != null &&
        IngredientCrate_Mushroom != null && IngredientCrate_Tomato_01 != null && IngredientCrate_Onion_01 != null &&
        IngredientCrate_Mushroom_01 != null && Sink != null && ChoppingBoard_Countertop1 != null &&
        ChoppingBoard_Countertop2 != null && Hob != null && Trash != null && DeliverCountertop != null &&
        Human_Agent != null && Plate_2 != null && Plate_3 != null)
        */
            {
            // R�cup�rer les positions des objets
            Vector3 agentPosition = artificialAgent.transform.position;
            Vector3 tomatoPosition = IngredientCrate_Tomato.transform.position;
            Vector3 onionPosition = IngredientCrate_Onion.transform.position;
            Vector3 mushroomPosition = IngredientCrate_Mushroom.transform.position;
            Vector3 tomato1Position = IngredientCrate_Tomato_01.transform.position;
            Vector3 onion1Position = IngredientCrate_Onion_01.transform.position;
            Vector3 mushroom1Position = IngredientCrate_Mushroom_01.transform.position;
            Vector3 sinkPosition = Sink.transform.position;
            Vector3 choppingBoard1Position = ChoppingBoard_Countetop1.transform.position;
            Vector3 choppingBoard2Position = ChoppingBoard_Countetop2.transform.position;
            Vector3 hobPosition = Hob.transform.position;
            Vector3 trashPosition = Trash.transform.position;
            Vector3 deliverCountertopPosition = DeliverCountertop.transform.position;
            Vector3 humanPosition = Human_Agent.transform.position;
            Vector3 plate2Position = Plate_2.transform.position;
            Vector3 plate3Position = Plate_3.transform.position;




            // Calculer les distances entre l'agent et les ingr�dients
            float tomatoDistance = Vector3.Distance(agentPosition, tomatoPosition);
            float onionDistance = Vector3.Distance(agentPosition, onionPosition);
            float mushroomDistance = Vector3.Distance(agentPosition, mushroomPosition);
            float tomato1Distance = Vector3.Distance(agentPosition, tomato1Position);
            float onion1Distance = Vector3.Distance(agentPosition, onion1Position);
            float mushroom1Distance = Vector3.Distance(agentPosition, mushroom1Position);
            float sinkDistance = Vector3.Distance(agentPosition, sinkPosition);
            float choppingBoard1Distance = Vector3.Distance(agentPosition, choppingBoard1Position);
            float choppingBoard2Distance = Vector3.Distance(agentPosition, choppingBoard2Position);
            float hobDistance = Vector3.Distance(agentPosition, hobPosition);
            float trashDistance = Vector3.Distance(agentPosition, trashPosition);
            float deliverCountertopDistance = Vector3.Distance(agentPosition, deliverCountertopPosition);
            float humanDistance = Vector3.Distance(agentPosition, humanPosition);
            float plate2Distance = Vector3.Distance(agentPosition, plate2Position);
            float plate3Distance = Vector3.Distance(agentPosition, plate3Position);

            // Afficher les distances dans la console

            /* 
            Debug.Log("Distance entre l'agent et l'ingr�dient tomate : " + tomatoDistance);
            Debug.Log("Distance entre l'agent et l'ingr�dient oignon : " + onionDistance);
            Debug.Log("Distance entre l'agent et l'ingr�dient champignon : " + mushroomDistance);
            Debug.Log("Distance entre l'agent et l'ingr�dient tomate1 : " + tomato1Distance);
            Debug.Log("Distance entre l'agent et l'ingr�dient oignon1 : " + onion1Distance);
            Debug.Log("Distance entre l'agent et l'ingr�dient champignon1 : " + mushroom1Distance);
            Debug.Log("Distance entre l'agent et l'�vier : " + sinkDistance);
            Debug.Log("Distance entre l'agent et la planche � d�couper 1 : " + choppingBoard1Distance);
            Debug.Log("Distance entre l'agent et la planche � d�couper 2 : " + choppingBoard2Distance);
            Debug.Log("Distance entre l'agent et la plaque de cuisson : " + hobDistance);
            Debug.Log("Distance entre l'agent et la poubelle : " + trashDistance);
            Debug.Log("Distance entre l'agent et le comptoir de livraison : " + deliverCountertopDistance);
            Debug.Log("Distance entre l'agent et l'agent humain : " + humanDistance);
            Debug.Log("Distance entre l'agent et l'assiette 2 : " + plate2Distance);
            Debug.Log("Distance entre l'agent et l'assiette 3 : " + plate3Distance);
            */


        }
        //else
        //{
        //    Debug.LogWarning("Les objets sp�cifi�s n'ont pas �t� trouv�s dans la sc�ne !");
        //}
    }
}