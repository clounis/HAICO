public interface IGameInput
{
    bool Interact { get; }
    bool PickUp { get; }
    // Add other necessary input actions
}
