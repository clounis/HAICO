
using Undercooked.Model;
using UnityEngine;

namespace Undercooked.Appliances
{
    public class Hob : Interactable, IResettable
    {
        private Vector3 initialPosition;
        private Quaternion initialRotation;

        public void Start()
        {
            var pan = CurrentPickable as CookingPot;
            pan?.DroppedIntoHob();
        }
        private new void Awake()
        {
            base.Awake(); // Call the base class Awake first, if needed.
            // Store initial position and rotation
            initialPosition = transform.position;
            initialRotation = transform.rotation;
        }

        // Second versION
        /*
         * 
        public override bool TryToDropIntoSlot(IPickable pickableToDrop)
        {
            if (CurrentPickable == null)
            {
                // Check if it's a CookingPot and not already at max ingredients or in an invalid state.
                if (pickableToDrop is CookingPot cookingPot && !cookingPot.IsBurned && cookingPot.Ingredients.Count < CookingPot.MaxNumberIngredients)
                {
                    return TryDropIfNotOccupied(pickableToDrop);
                }
                Debug.Log("Hob is empty but the item cannot be placed here.");
                return false;
            }
            else
            {
                Debug.Log("Hob is already occupied.");
                return false;
            }
        }

        */

        
        public override bool TryToDropIntoSlot(IPickable pickableToDrop)
        {
                Debug.Log("Hob: TryToDropIntoSlot called");

                if (CurrentPickable != null)
                {
                    Debug.Log("Hob: CurrentPickable is not null");
                    if (CurrentPickable is CookingPot cookingPot)
                    {
                        return cookingPot.TryToDropIntoSlot(pickableToDrop);
                    }
                    return false;
                }

                if (pickableToDrop is CookingPot cookingPot1)
                {
                    Debug.Log("Hob: Dropping CookingPot onto Hob");
                    return TryDropIfNotOccupied(pickableToDrop);
                }

                Debug.Log("Hob: Invalid item tried to drop onto Hob");
                return false;
            }

        
        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            if (CurrentPickable == null) return null;

            var output = CurrentPickable;
            var interactable = CurrentPickable as Interactable;
            interactable?.ToggleHighlightOff();

            // stop cooking process
            var pan = CurrentPickable as CookingPot;
            pan?.RemovedFromHob();

            CurrentPickable = null;
            return output;
        }

        private bool TryDropIfNotOccupied(IPickable pickable)
        {
            if (CurrentPickable != null)
            {
                Debug.Log("Hob: Slot is already occupied");
                return false;
            }

            Debug.Log("Hob: Slot is empty, placing item");
            CurrentPickable = pickable;
            CurrentPickable.gameObject.transform.SetParent(Slot);
            CurrentPickable.gameObject.transform.SetPositionAndRotation(Slot.position, Quaternion.identity);

            // start cooking
            var pan = CurrentPickable as CookingPot;
            pan?.DroppedIntoHob();
            return true;
        }

    
        /*
        public void ResetObject()
        {
            // Ensure no pot is currently being interacted with
        
            if (CurrentPickable != null)
            {
                var cookingPot = CurrentPickable as CookingPot;
                if (cookingPot != null)
                {
                    cookingPot.RemovedFromHob();
                }
                CurrentPickable = null;
            }

            // Reset physical properties
            transform.position = initialPosition;
            transform.rotation = initialRotation;

            Debug.Log("Hob reset and ready to accept new interactions.");
     
        }
        */

        public void ResetObject()
        {
           /* 
            var pan = CurrentPickable as CookingPot;
            pan?.DroppedIntoHob();
            */
            Debug.Log("HobReset");
        }

  
    }
}
