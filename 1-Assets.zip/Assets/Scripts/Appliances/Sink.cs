using System.Collections;
using System.Collections.Generic;
using Undercooked.Model;
using Undercooked.Player;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.UI;

namespace Undercooked.Appliances
{
    // -- Particular Features --
    // we can drop a pile of plates into Sink
    // when player breaks contact, cleaning process is paused (it could be resumed)
    // when one plate is cleaned the next one starts automatically

    public class Sink : Interactable
    {
        [SerializeField] private Slider slider;
        [SerializeField] private List<Transform> dirtySlots = new List<Transform>();

        private readonly Stack<Plate> _cleanPlates = new Stack<Plate>();
        private readonly Stack<Plate> _dirtyPlates = new Stack<Plate>();

        //private const float CleaningTime = 3f;
        public const float CleaningTime = 3f;
        private float _currentCleaningTime;
        private Coroutine _cleanCoroutine;

        public delegate void CleanStatus(PlayerController playerController);
        public static event CleanStatus OnCleanStart;
        public static event CleanStatus OnCleanStop;

        public bool IsCleaningInProgress => _cleanCoroutine != null;
        public float CleaningProgress => slider.value;

        protected override void Awake()
        {
            base.Awake();

#if UNITY_EDITOR
            Assert.IsNotNull(dirtySlots);
            Assert.IsNotNull(_cleanPlates);
            Assert.IsNotNull(_dirtyPlates);
            Assert.IsNotNull(slider);
#endif
        }

        public override bool TryToDropIntoSlot(IPickable pickableToDrop)
        {
            if (!(pickableToDrop is Plate plate)) return false;
            if (!plate.IsEmpty() || plate.IsClean) return false;
            AddPileDirtyPlatesRecursively(plate);
            return true;
        }

        /// <summary>
        /// The first two dirty plate slots are visible, all subsequent are placed out of player's sight
        /// </summary>
        
        /*
         * private void AddPileDirtyPlatesRecursively(Plate plate)
        {
            Plate nextPlate = plate.Slot.GetComponentInChildren<Plate>();
            if (nextPlate != null)
            {
                nextPlate.transform.SetParent(null);
                AddPileDirtyPlatesRecursively(nextPlate);
            }

            _dirtyPlates.Push(plate);
            int dirtySize = _dirtyPlates.Count;

            Transform dirtySlot = dirtySize <= 2 ? dirtySlots[dirtySize - 1] : dirtySlots[2];

            plate.transform.SetParent(dirtySlot);
            plate.transform.SetPositionAndRotation(dirtySlot.transform.position, dirtySlot.transform.rotation);
        }
        */

        private void AddPileDirtyPlatesRecursively(Plate plate)
        {
            Plate nextPlate = plate.Slot.GetComponentInChildren<Plate>();
            if (nextPlate != null)
            {
                nextPlate.transform.SetParent(null);
                AddPileDirtyPlatesRecursively(nextPlate);
            }

            _dirtyPlates.Push(plate);
            int dirtySize = _dirtyPlates.Count;

            // Ensure the index used is within the bounds of the dirtySlots list
            int slotIndex = Mathf.Min(dirtySize - 1, dirtySlots.Count - 1);
            Transform dirtySlot = dirtySlots[slotIndex];

            plate.transform.SetParent(dirtySlot);
            plate.transform.SetPositionAndRotation(dirtySlot.transform.position, dirtySlot.transform.rotation);

//            plate.transform.SetPositionAndRotation(dirtySlot.position, Quaternion.identity);
        }

        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            if (playerHoldPickable != null) return null;

            return _cleanPlates.Count > 0 ? _cleanPlates.Pop() : null;
        }

        public override void Interact(PlayerController playerController)
        {
            base.Interact(playerController);

            if (_dirtyPlates.Count == 0) return;

            if (_cleanCoroutine == null)
            {
                _currentCleaningTime = 0f;
                slider.value = 0f;
                slider.gameObject.SetActive(true);
                StartCleanCoroutine();
                return;
            }

            StopCleanCoroutine();
            StartCleanCoroutine();
        }

        private IEnumerator Clean()
        {
            slider.gameObject.SetActive(true);
            while (_currentCleaningTime < CleaningTime)
            {
                slider.value = _currentCleaningTime / CleaningTime;
                _currentCleaningTime += Time.deltaTime;
                yield return null;
            }

            // clean the top of the _dirtyPlates stack
            var plateToClean = _dirtyPlates.Pop();
            plateToClean.SetClean();

            // put the clean plate into the top of the cleanPile (physically)
            var topStackSlot = _cleanPlates.Count == 0 ? Slot : _cleanPlates.Peek().Slot;

            // all plates parented to the base Slot, but physically positioned on the top of the stack
            plateToClean.transform.SetParent(Slot);
            plateToClean.transform.SetPositionAndRotation(topStackSlot.transform.position, Quaternion.identity);

            _cleanPlates.Push(plateToClean);

            _cleanCoroutine = null;
            _currentCleaningTime = 0f;

            // Chain next plate
            if (_dirtyPlates.Count > 0)
            {
                StartCleanCoroutine();
                yield break;
            }

            StopCleanCoroutine();
        }

        public override void ToggleHighlightOff()
        {
            base.ToggleHighlightOff();
            StopCleanCoroutine();
        }

        private void StartCleanCoroutine()
        {
            OnCleanStart?.Invoke(LastPlayerControllerInteracting);
            _cleanCoroutine = StartCoroutine(Clean());
        }

        private void StopCleanCoroutine()
        {
            OnCleanStop?.Invoke(LastPlayerControllerInteracting);
            slider.gameObject.SetActive(false);
            if (_cleanCoroutine != null) StopCoroutine(_cleanCoroutine);
        }

        public void ResetDirtySlots()
        {
            while (_dirtyPlates.Count > 0)
            {
                Plate plate = _dirtyPlates.Pop();
              //  Destroy(plate.gameObject); // Optionally, if you're pooling objects, return them to the pool instead of destroying.
            }

            // Optionally, if you visually represent dirty plates in slots and need to clear them,
            // iterate through the dirtySlots transforms and remove any child objects.
            foreach (Transform slot in dirtySlots)
            {
                for (int i = 0; i < slot.childCount; i++)
                {
                    Destroy(slot.GetChild(i).gameObject); // Or return to object pool if applicable.
                }
            }

            // Reset the slider and cleaning time in case they were mid-process.
            _currentCleaningTime = 0f;
            slider.value = 0;
            slider.gameObject.SetActive(false);

            // Ensure any ongoing cleaning coroutine is stopped.
            if (_cleanCoroutine != null)
            {
                StopCoroutine(_cleanCoroutine);
                _cleanCoroutine = null;
            }
        }
    }
}
/*
using System.Collections;
using System.Collections.Generic;
using Undercooked.Model;
using Undercooked.Player;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.UI;

namespace Undercooked.Appliances
{
    // -- Particular Features --
    // we can drop a pile of plates into Sink
    // when player breaks contact, cleaning process is paused (it could be resumed)
    // when one plate is cleaned the next one starts automatically

    public class Sink : Interactable
    {
        [SerializeField] private Slider slider;
        [SerializeField] private List<Transform> dirtySlots = new List<Transform>();
      

        private readonly Stack<Plate> _cleanPlates = new Stack<Plate>();
        private readonly Stack<Plate> _dirtyPlates = new Stack<Plate>();

        //private const float CleaningTime = 3f;
        public const float CleaningTime = 3f;
        private float _currentCleaningTime;
        private Coroutine _cleanCoroutine;
        //        public GameObject CleanSlot;

        
        // ad for ai agent
        private bool _playerInteracting = false; 

        public delegate void CleanStatus(PlayerController playerController);
        public static event CleanStatus OnCleanStart;
        public static event CleanStatus OnCleanStop;

        public bool IsCleaningInProgress => _cleanCoroutine != null;
        public float CleaningProgress => slider.value;

        

        protected override void Awake()
        {
            base.Awake();

#if UNITY_EDITOR
            Assert.IsNotNull(dirtySlots);
            Assert.IsNotNull(_cleanPlates);
            Assert.IsNotNull(_dirtyPlates);
            Assert.IsNotNull(slider);
#endif
        }

        public override bool TryToDropIntoSlot(IPickable pickableToDrop)
        {
            if (!(pickableToDrop is Plate plate)) return false;
            if (!plate.IsEmpty() || plate.IsClean) return false;
            AddPileDirtyPlatesRecursively(plate);
            return true;
        }

        /// <summary>
        /// The first two dirty plate slots are visible, all subsequent are placed out of player's sight
        /// </summary>
      
        /* TRUE ONE 
        private void AddPileDirtyPlatesRecursively(Plate plate)
        {
            Plate nextPlate = plate.Slot.GetComponentInChildren<Plate>();
            if (nextPlate != null)
            {
                nextPlate.transform.SetParent(null);
                AddPileDirtyPlatesRecursively(nextPlate);
            }

            _dirtyPlates.Push(plate);
            int dirtySize = _dirtyPlates.Count;

            Transform dirtySlot = dirtySize <= 2 ? dirtySlots[dirtySize - 1] : dirtySlots[2];

            plate.transform.SetParent(dirtySlot);
            plate.transform.SetPositionAndRotation(dirtySlot.transform.position, dirtySlot.transform.rotation);
        }
        
private void AddPileDirtyPlatesRecursively(Plate plate)
        {
            Plate nextPlate = plate.Slot.GetComponentInChildren<Plate>();
            if (nextPlate != null)
            {
                nextPlate.transform.SetParent(null);
                AddPileDirtyPlatesRecursively(nextPlate);
            }

            _dirtyPlates.Push(plate);
            int dirtySize = _dirtyPlates.Count;

            // Adjusted to safely handle indexes out of range by using the last slot for overflow
            int slotIndex = dirtySize <= dirtySlots.Count ? dirtySize - 1 : dirtySlots.Count - 1;
            Transform dirtySlot = dirtySlots[slotIndex];

            plate.transform.SetParent(dirtySlot);
            plate.transform.SetPositionAndRotation(dirtySlot.position, dirtySlot.rotation);
        }

        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            if (playerHoldPickable != null) return null;

            return _cleanPlates.Count > 0 ? _cleanPlates.Pop() : null;
        }


        // TEST 

        public override void Interact(PlayerController playerController)
        {
            _playerInteracting = true;
            // Only start cleaning if there's something to clean and it's not already in progress
            if (_cleanCoroutine == null && _dirtyPlates.Count > 0 && !_playerInteracting)
            {
                StartCleanCoroutine();
            }
            else if (_cleanCoroutine == null && _playerInteracting && _dirtyPlates.Count > 0)
            {
                // Resume cleaning process from current progress
                ResumeCleaningProcess();
            }
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                _playerInteracting = false;
                // Pause cleaning process but do not reset progress
                PauseCleaningProcess();
            }
        }

        private IEnumerator Clean()
        {
            slider.gameObject.SetActive(true);
            while (_currentCleaningTime < CleaningTime && _dirtyPlates.Count > 0)
            {
                if (!_playerInteracting)
                {
                    // Pause the coroutine if the player is not interacting, without breaking the coroutine
                    yield return null;
                }
                else
                {
                    _currentCleaningTime += Time.deltaTime;
                    slider.value = _currentCleaningTime / CleaningTime;
                    if (_currentCleaningTime >= CleaningTime)
                    {
                        // Once a plate is cleaned, reset for next plate and handle clean plate
                        CleanPlate();
                    }
                    yield return null;
                }
            }

            if (_dirtyPlates.Count == 0 || !_playerInteracting)
            {
                ResetCleaningProcess();
            }
        }

        private void ResetCleaningProcess()
        {
            // This will stop the current cleaning coroutine if it's running
            if (_cleanCoroutine != null)
            {
                StopCoroutine(_cleanCoroutine);
                _cleanCoroutine = null;
            }

            // Reset the current cleaning time to 0 to start fresh next time
            _currentCleaningTime = 0f;
            slider.value = 0f; // Also reset the slider's progress to 0

            // Make sure the slider is not visible when not cleaning
            slider.gameObject.SetActive(false);
        }
        /*
        public IEnumerator Clean()
        {
            slider.gameObject.SetActive(true); // Make sure the slider is visible throughout the cleaning process

            // Continue cleaning the current plate until the cleaning time is reached
            while (_dirtyPlates.Count > 0 && _currentCleaningTime < CleaningTime)
            {
                slider.value = _currentCleaningTime / CleaningTime;
                _currentCleaningTime += Time.deltaTime;
                yield return null;
            }

            if (_dirtyPlates.Count > 0 && _currentCleaningTime >= CleaningTime)
            {
                // Once a plate is cleaned, move it to the clean pile
                var plateToClean = _dirtyPlates.Pop();
                plateToClean.SetClean();
                _cleanPlates.Push(plateToClean);

                // Physically position the plate in the clean pile location
                var topStackSlot = _cleanPlates.Count == 0 ? Slot : _cleanPlates.Peek().Slot;
                plateToClean.transform.SetParent(Slot); // Keep all plates parented to the base Slot
                plateToClean.transform.SetPositionAndRotation(topStackSlot.position, Quaternion.identity);

                // Reset the timer for the next plate
                _currentCleaningTime = 0f;
                slider.value = 0f; // Reset the slider value for the next cleaning process
            }

            // Deactivate the slider if there are no more plates to clean
            if (_dirtyPlates.Count == 0)
            {
                slider.gameObject.SetActive(false);
            }

            _cleanCoroutine = null;

            // Automatically start cleaning the next plate if any are dirty
            if (_dirtyPlates.Count > 0)
            {
                StartCleanCoroutine();
            }
        }
        */
/*
        private void CleanPlate()
        {
            // Clean the top of the _dirtyPlates stack and move it to clean plates stack
            var plateToClean = _dirtyPlates.Pop();
            plateToClean.SetClean();
            _cleanPlates.Push(plateToClean);

            // Reset progress for the next plate
            _currentCleaningTime = 0;
            slider.value = 0;

            // If there are more dirty plates, continue cleaning, else hide slider
            if (_dirtyPlates.Count > 0)
            {
                slider.gameObject.SetActive(true);
            }
            else
            {
                slider.gameObject.SetActive(false);
            }
        }

        private void ResumeCleaningProcess()
        {
            if (_dirtyPlates.Count > 0)
            {
                StartCleanCoroutine();
            }
        }


        private void PauseCleaningProcess()
        {
            if (_cleanCoroutine != null)
            {
                StopCoroutine(_cleanCoroutine);
                _cleanCoroutine = null;
                // Do not reset _currentCleaningTime here to preserve progress
            }
        }

        /* TRUE ONE

        public IEnumerator Clean()
        {
            slider.gameObject.SetActive(true);
            while (_currentCleaningTime < CleaningTime)
            {
                slider.value = _currentCleaningTime / CleaningTime;
                _currentCleaningTime += Time.deltaTime;
                yield return null;
            }

            // clean the top of the _dirtyPlates stack
            var plateToClean = _dirtyPlates.Pop();
            plateToClean.SetClean();

            // put the clean plate into the top of the cleanPile (physically)
            var topStackSlot = _cleanPlates.Count == 0 ? Slot : _cleanPlates.Peek().Slot;

            // all plates parented to the base Slot, but physically positioned on the top of the stack
            plateToClean.transform.SetParent(Slot);
            plateToClean.transform.SetPositionAndRotation(topStackSlot.transform.position, Quaternion.identity);

            _cleanPlates.Push(plateToClean);

            _cleanCoroutine = null;
            _currentCleaningTime = 0f;

            // Chain next plate
            if (_dirtyPlates.Count > 0)
            {
                StartCleanCoroutine();
                yield break;
            }

            StopCleanCoroutine();
        }
        
        */
/*
        public override void ToggleHighlightOff()
        {
            base.ToggleHighlightOff();
          //  StopCleanCoroutine();
        }

        public void StartCleanCoroutine(PlayerController initiatingPlayer)
        {
            if (IsCleaningInProgress && _playerControllerInteracting == initiatingPlayer) return; // Avoid starting multiple coroutines by the same player
            _playerControllerInteracting = initiatingPlayer; // Track which player is interacting
            OnCleanStart?.Invoke(initiatingPlayer);
            _cleanCoroutine = StartCoroutine(Clean(initiatingPlayer));
        }


        /*
        public void StartCleanCoroutine()
        {
            if (IsCleaningInProgress) return; // Avoid starting multiple coroutines
            OnCleanStart?.Invoke(LastPlayerControllerInteracting);
            _cleanCoroutine = StartCoroutine(Clean());
        }
        
        private void StopCleanCoroutine()
        {
            if (_cleanCoroutine != null)
            {
                StopCoroutine(_cleanCoroutine);
                _cleanCoroutine = null;
            }
            OnCleanStop?.Invoke(LastPlayerControllerInteracting);
            // Don't deactivate the slider here if you want to keep the progress visible when cleaning is paused
        }


*/
        /*
        private void StopCleanCoroutine()
        {
            OnCleanStop?.Invoke(LastPlayerControllerInteracting);
            slider.gameObject.SetActive(false);
            if (_cleanCoroutine != null) StopCoroutine(_cleanCoroutine);
        }
        */
        // FOR AGENT PURPOSE
        /*
         private void AddDirtyPlate(Plate plate)
        {
            _dirtyPlates.Push(plate);
            //UpdateDirtyPlateVisuals();
            if (!IsCleaningInProgress)
            {
                StartCleaningProcess();
            }
        }
        */
        /*  private Plate currentlyCleaningPlate;
          [SerializeField] private Transform cleanPileTransform; // Ensure this line is present
          public void StartCleaningProcess()
          {
              if (_cleanCoroutine == null && _dirtyPlates.Count > 0)
              {
                  currentlyCleaningPlate = _dirtyPlates.Peek(); // Get the top dirty plate
                  _cleanCoroutine = StartCoroutine(CleanPlateCoroutine());
                  slider.gameObject.SetActive(true);
              }
          }

          private IEnumerator CleanPlateCoroutine()
          {
              while (_currentCleaningTime < CleaningTime)
              {
                  _currentCleaningTime += Time.deltaTime;
                  slider.value = _currentCleaningTime / CleaningTime;
                  yield return null;
              }

              // Cleaning complete
              CleanCurrentPlate();
          }

          private void CleanCurrentPlate()
          {
              if (currentlyCleaningPlate != null)
              {
                  _dirtyPlates.Pop(); // Remove from dirty plates
                  currentlyCleaningPlate.SetClean();
                  currentlyCleaningPlate.transform.SetParent(cleanPileTransform, false); // Move to clean pile
                  _cleanPlates.Push(currentlyCleaningPlate); // Add to clean plates stack
                  currentlyCleaningPlate = null; // Reset current plate being cleaned
              }

              _currentCleaningTime = 0f; // Reset time for next plate
              slider.gameObject.SetActive(false); // Hide progress bar

              // Check if there are more plates to clean
              if (_dirtyPlates.Count > 0) StartCleaningProcess();
              else _cleanCoroutine = null; // No more plates to clean
          }

          public void CancelCleaningProcess()
          {
              if (IsCleaningInProgress)
              {
                  StopCoroutine(_cleanCoroutine);
                  _cleanCoroutine = null;
                  slider.gameObject.SetActive(false);
                  // Optionally reset currentCleaningTime if you want to restart cleaning from 0 next time
                  // currentCleaningTime = 0f;
              }
          }

          // Call this method to manually resume cleaning, useful for agent-initiated actions
          public void ResumeCleaningProcess()
          {
              if (!IsCleaningInProgress && _dirtyPlates.Count > 0) StartCleaningProcess();
          }



          */

        /*
        public void StartCleaningProcess()
        {
            if (_cleanCoroutine == null && _dirtyPlates.Count > 0)
            {
                _cleanCoroutine = StartCoroutine(CleanPlateCoroutine());
            }
        }

        private IEnumerator CleanPlateCoroutine()
        {
            slider.gameObject.SetActive(true);
            while (_dirtyPlates.Count > 0)
            {
                Plate plate = _dirtyPlates.Peek();
                for (_currentCleaningTime = 0f; _currentCleaningTime < CleaningTime; _currentCleaningTime += Time.deltaTime)
                {
                    slider.value = _currentCleaningTime / CleaningTime;
                    yield return null;
                }
                // Cleaning complete
                _cleanPlates.Push(_dirtyPlates.Pop());
                plate.SetClean();
                //UpdateDirtyPlateVisuals();
            }
            slider.gameObject.SetActive(false);
            _cleanCoroutine = null;
        }

        

    }

}
*/

