using Undercooked.Model;
using UnityEngine;

namespace Undercooked.Appliances
{
    public class Countertop : Interactable, IResettable
    {

        private Vector3 initialPosition;
        private Quaternion initialRotation;
        private IPickable initialPickable; 
        protected override void Awake()
        {
            base.Awake();
            initialPosition = transform.position;
            initialRotation = transform.rotation;
            if (CurrentPickable != null)
            {
                initialPickable = CurrentPickable;
            }
        }
        public override bool TryToDropIntoSlot(IPickable pickableToDrop)
        {
            if (CurrentPickable == null) return TryDropIfNotOccupied(pickableToDrop);

            return CurrentPickable switch
            {
                CookingPot cookingPot => cookingPot.TryToDropIntoSlot(pickableToDrop),
                Ingredient ingredient => ingredient.TryToDropIntoSlot(pickableToDrop),
                Plate plate => plate.TryToDropIntoSlot(pickableToDrop),
                _ => false
            };
        }
        // OLD VERSION OF TRYTOPICKUPFROMSLOT
        /* public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
         {
             if (CurrentPickable == null) return null;

             var output = CurrentPickable;
             var interactable = CurrentPickable as Interactable;
             interactable?.ToggleHighlightOff();
             CurrentPickable = null;
             return output;
         }
        */

        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            if (CurrentPickable == null) return null;

            var output = CurrentPickable;
            ClearCurrentPickable();

            return output;
        }
        private void ClearCurrentPickable()
        {
            if (CurrentPickable != null)
            {
                var pickableTransform = (CurrentPickable as MonoBehaviour)?.transform;
                if (pickableTransform != null && pickableTransform.parent == Slot)
                {
                    pickableTransform.parent = null;
                }
                CurrentPickable = null;
            }
        }
        private bool TryDropIfNotOccupied(IPickable pickable)
        {
            if (CurrentPickable != null) return false;

            CurrentPickable = pickable;
            var pickableTransform = (CurrentPickable as MonoBehaviour)?.transform;
            if (pickableTransform != null)
            {
                pickableTransform.SetParent(Slot);
                pickableTransform.SetPositionAndRotation(Slot.position, Quaternion.identity);
            }
            return true;
        }
        //OLD VERSION OF TRYDROPIFNOTOCCUPIED
        /* 
        private bool TryDropIfNotOccupied(IPickable pickable)
        {
            if (CurrentPickable != null) return false;

            CurrentPickable = pickable;
            CurrentPickable.gameObject.transform.SetParent(Slot);
            CurrentPickable.gameObject.transform.SetPositionAndRotation(Slot.position, Quaternion.identity);
            return true;
        }
        */
        public void ResetObject()
        {
            transform.position = initialPosition;
            transform.rotation = initialRotation;

            // If there's an initial pickable, reset it back to the countertop
            if (initialPickable != null)
            {
                if (CurrentPickable != null)
                {
                    // If there is a current pickable, move it away or reset its state
                    CurrentPickable.Drop();
                }

                // Reset initial pickable
                CurrentPickable = initialPickable;
                var initialTransform = (CurrentPickable as MonoBehaviour)?.transform;
                if (initialTransform != null)
                {
                    initialTransform.SetParent(Slot);
                    initialTransform.SetPositionAndRotation(Slot.position, Quaternion.identity);
                }
            }
            else
            {
                // Ensure no current pickable remains
                if (CurrentPickable != null)
                {
                    CurrentPickable.Drop();
                    ClearCurrentPickable();
                }
            }
        }
    }
}
