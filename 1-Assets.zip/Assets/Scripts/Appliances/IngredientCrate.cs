using Undercooked.Model;
using UnityEngine;
using UnityEngine.Assertions;

namespace Undercooked.Appliances
{
    public class IngredientCrate : Interactable, IResettable
    { 
        [SerializeField] private Ingredient ingredientPrefab;
        private Animator _animator;
        private static readonly int OpenHash = Animator.StringToHash("Open");

        protected override void Awake()
        {
            base.Awake();
            _animator = GetComponentInChildren<Animator>();
            
            #if UNITY_EDITOR
                Assert.IsNotNull(ingredientPrefab);
                Assert.IsNotNull(_animator);
            #endif
        }

        public override bool TryToDropIntoSlot(IPickable pickableToDrop)
        {
              if (CurrentPickable != null) return false;
            
            CurrentPickable = pickableToDrop;
            CurrentPickable.gameObject.transform.SetParent(Slot);
            pickableToDrop.gameObject.transform.SetPositionAndRotation(Slot.position, Quaternion.identity);
            return true;
        }

       
        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            if (CurrentPickable == null)
            {
                _animator.SetTrigger(OpenHash);
                return Instantiate(ingredientPrefab, Slot.transform.position, Quaternion.identity);
            }

            var output = CurrentPickable;
            var interactable = CurrentPickable as Interactable;
            interactable?.ToggleHighlightOff();
            CurrentPickable = null;
            return output;
        }

        // NEW VERSION FOR EPISODE RESET

        /*
         * public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            if (ingredientPrefab == null)
            {
                Debug.LogError("Ingredient prefab is missing.");
                return null;
            }

            if (CurrentPickable == null)
            {
                _animator.SetTrigger(OpenHash);
                var newIngredient = Instantiate(ingredientPrefab, Slot.transform.position, Quaternion.identity);
                // Initialize the ingredient if necessary
                return newIngredient;
            }
            return null;
        }
        // END

        public IPickable CurrentPickableProperty // ADD FOR CookerAgent
        {
            get
            {
                return CurrentPickable;
            }
        }
        */
        public void ResetObject()
        {
           // transform.position = initialPosition;
           // transform.rotation = initialRotation;
            // Clear any ingredients that might be on the crate
            ClearCurrentPickable();
        }

        private void ClearCurrentPickable()
        {
            if (CurrentPickable != null)
            {
                var pickableTransform = (CurrentPickable as MonoBehaviour)?.transform;
                if (pickableTransform != null && pickableTransform.parent == Slot)
                {
                    pickableTransform.parent = null;
                }
                CurrentPickable = null;
            }
        }
    }

    
}
