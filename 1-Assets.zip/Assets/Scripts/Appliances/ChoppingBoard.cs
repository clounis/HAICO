using System.Collections;
using Undercooked.Model;
using Undercooked.Player;
using UnityEngine;
using UnityEngine.Assertions;
using Slider = UnityEngine.UI.Slider;

namespace Undercooked.Appliances
{
    public class ChoppingBoard : Interactable
    {
        [SerializeField] private Transform knife;
        [SerializeField] private Slider slider;

        private float _finalProcessTime;
        private float _currentProcessTime;
        private Coroutine _chopCoroutine;
        private Ingredient _ingredient;
        private bool _isChopping;
        //  public bool IsChoppingInProgress { get; private set; } //ADD FOR COOKER AGENT SCRIPT
        public delegate void ChoppingStatus(PlayerController playerController);
        public static event ChoppingStatus OnChoppingStart;
        public static event ChoppingStatus OnChoppingStop;

        protected override void Awake()
        {
#if UNITY_EDITOR
            Assert.IsNotNull(slider);
            Assert.IsNotNull(slider);
#endif

            base.Awake();
            slider.gameObject.SetActive(false);
        }
        public bool IsChoppingInProgress  //NEW ONE FOR COOKER AGENT SCRIPT
        {
            get { return _chopCoroutine != null; }
        }



        public override void Interact(PlayerController playerController)
        {
            LastPlayerControllerInteracting = playerController;
            base.Interact(playerController);
            if (CurrentPickable == null ||
                _ingredient == null ||
                _ingredient.Status != IngredientStatus.Raw) return;

            if (_chopCoroutine == null)
            {
                _finalProcessTime = _ingredient.ProcessTime;
                _currentProcessTime = 0f;
                slider.value = 0f;
                slider.gameObject.SetActive(true);
                StartChopCoroutine();
                return;
            }

            if (_isChopping == false)
            {
                StartChopCoroutine();
            }
        }

        // Method for CookerAgent to interact with ChoppingBoard
       /* public void InteractWithCookerAgent(CookerAgent agent)
        {
            Debug.Log("InteractWithCookerAgent called");
            // Start the chopping coroutine if conditions are met
            if (_chopCoroutine == null && _ingredient != null && _ingredient.Status == IngredientStatus.Raw)
            {
                Debug.Log("Starting chopping process for agent.");
                StartChopCoroutineForAgent(agent);
            }
            else
            {
                Debug.Log("Cannot start chopping: No raw ingredient or already chopping.");
            }
        }
        private void StartChopCoroutineForAgent(CookerAgent agent)
        {
            Animator agentAnimator = agent.GetComponent<Animator>();
            if (agentAnimator != null)
            {
                agentAnimator.SetBool("isChopping", true); // Start animation
            }

            _chopCoroutine = StartCoroutine(ChopForAgent(agent));
        }

        */
        private IEnumerator ChopForAgent(CookerAgent agent)
        {
            Debug.Log("Chop coroutine started");
            _isChopping = true;
            while (_currentProcessTime < _finalProcessTime)
            {
                Debug.Log($"Chopping... {_currentProcessTime}/{_finalProcessTime}");
                slider.value = _currentProcessTime / _finalProcessTime;
                _currentProcessTime += Time.deltaTime;
                yield return null;
            }

            Debug.Log("Chopping finished");
            // Chopping finished
            _ingredient.ChangeToProcessed();
            slider.gameObject.SetActive(false);
            _isChopping = false;
            _chopCoroutine = null;

            // Stop the animation
            Animator agentAnimator = agent.GetComponent<Animator>();

            if (agentAnimator != null)
            {
                agentAnimator.SetBool("isChopping", false); // Replace "isChopping" with the appropriate parameter name
            }
        }


        // ADD FOR COOKER AGENT
        public Ingredient GetCurrentIngredient()
        {
            return CurrentPickable as Ingredient;
        }


        private void StartChopCoroutine()
        {
            OnChoppingStart?.Invoke(LastPlayerControllerInteracting);
            _chopCoroutine = StartCoroutine(Chop());
        }

        private void StopChopCoroutine()
        {
            OnChoppingStop?.Invoke(LastPlayerControllerInteracting);
            _isChopping = false;
            if (_chopCoroutine != null) StopCoroutine(_chopCoroutine);
        }

        public override void ToggleHighlightOff()
        {
            base.ToggleHighlightOff();
            StopChopCoroutine();
        }

        public IEnumerator Chop()
        {
            _isChopping = true;
            while (_currentProcessTime < _finalProcessTime)
            {
                slider.value = _currentProcessTime / _finalProcessTime;
                _currentProcessTime += Time.deltaTime;
                yield return null;
            }

            // finished
            _ingredient.ChangeToProcessed();
            slider.gameObject.SetActive(false);
            _isChopping = false;
            _chopCoroutine = null;
            OnChoppingStop?.Invoke(LastPlayerControllerInteracting);
        }

        public override bool TryToDropIntoSlot(IPickable pickableToDrop)
        {
            if (pickableToDrop is Ingredient)
            {
                return TryDropIfNotOccupied(pickableToDrop);
            }
            return false;
        }

        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            // only allow Pickup after we finish chopping the ingredient. Essentially locking it in place.
            if (CurrentPickable == null) return null;
            if (_chopCoroutine != null) return null;

            var output = CurrentPickable;
            _ingredient = null;
            var interactable = CurrentPickable as Interactable;
            interactable?.ToggleHighlightOff();
            CurrentPickable = null;
            knife.gameObject.SetActive(true);
            return output;
        }

        private bool TryDropIfNotOccupied(IPickable pickable)
        {
            if (CurrentPickable != null) return false;
            CurrentPickable = pickable;
            _ingredient = pickable as Ingredient;
            if (_ingredient == null) return false;

            _finalProcessTime = _ingredient.ProcessTime;

            CurrentPickable.gameObject.transform.SetParent(Slot);
            CurrentPickable.gameObject.transform.SetPositionAndRotation(Slot.position, Quaternion.identity);
            knife.gameObject.SetActive(false);
            return true;
        }
        public float CurrentProcessTime => _currentProcessTime;
        public float FinalProcessTime => _finalProcessTime;
        public IPickable CurrentPickableProperty // ADD FOR CookerAgent
        {
            get
            {
                return CurrentPickable;
            }
        }

        // FOR COOKER AGENT
        //
        
        public void InteractWithCookerAgent(CookerAgent agent, Ingredient ingredient)
        {
            // Check if already chopping another ingredient
            if (IsChoppingInProgress || ingredient.Status != IngredientStatus.Raw) return;

            // Start the chopping process
            StartCoroutine(ChopIngredient(ingredient, agent));
        }

        private IEnumerator ChopIngredient(Ingredient ingredient, CookerAgent agent)
        {
            // Start animation if applicable
         //   agent.TriggerChoppingAnimation(true);

            // Simulate chopping time
            float choppingTime = 5.0f; // Adjust the time according to your game
            float elapsedTime = 0;

            while (elapsedTime < choppingTime)
            {
                elapsedTime += Time.deltaTime;
                yield return null;
            }

            // Change ingredient status to Processed
            _ingredient.ChangeToProcessed();
            //  ingredient.Status = IngredientStatus.Processed;

            // Stop animation
           // agent.TriggerChoppingAnimation(false);
        }
        

        //FOR NEW EPIDSODE PURPOSE
        public void ResetChoppingBoard()
        {
            // Stop any ongoing chopping coroutine
            if (_chopCoroutine != null)
            {
                StopCoroutine(_chopCoroutine);
                _chopCoroutine = null;
            }

            // Reset the slider to be invisible and at 0 value
            slider.gameObject.SetActive(false);
            slider.value = 0f;

            // Remove any ingredient from the chopping board
            if (_ingredient != null)
            {
                Destroy(_ingredient.gameObject); // This removes the ingredient GameObject from the scene
                _ingredient = null;
            }

            // Ensure the knife is visible again
            knife.gameObject.SetActive(true);

            // Reset any internal state flags
            _isChopping = false;
            _currentProcessTime = 0f;
            _finalProcessTime = 0f;

            // Clear the current pickable reference
            CurrentPickable = null;
        }

    }
}