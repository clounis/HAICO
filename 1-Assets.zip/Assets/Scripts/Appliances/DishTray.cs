using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Undercooked.Model;
using UnityEngine;

namespace Undercooked.Appliances
{
    public class DishTray : Interactable, IResettable
    {
        private List<Plate> _dirtyPlates = new List<Plate>();
        private List<Coroutine> _returnPlateCoroutines = new List<Coroutine>();
        public override bool TryToDropIntoSlot(IPickable pickableToDrop) => false;
        public static DishTray Instance { get; private set; }

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
            }
            else
            {
                Destroy(gameObject);
            }
        }

        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            if (_dirtyPlates.Count > 0)
            {
                var plate = _dirtyPlates[0];
                _dirtyPlates.RemoveAt(0);
                return plate;
            }

            return null;
        }

        public void AddDirtyPlate(Plate plate)
        {
            plate.SetDirty();
            plate.transform.localRotation = Quaternion.identity;
            plate.transform.localScale = Vector3.one;

            if (_dirtyPlates.Count > 0)
            {
                var lastPlate = _dirtyPlates[_dirtyPlates.Count - 1];
                plate.transform.position = lastPlate.transform.position + new Vector3(0, 0.1f, 0);
            }
            else
            {
                plate.transform.position = transform.position + new Vector3(0, 0.3f, 0);
            }

            plate.transform.SetParent(transform, true);
            _dirtyPlates.Add(plate);
        }

        public Plate GetTopPlate()
        {
            if (_dirtyPlates.Count == 0) return null;

            var topPlate = _dirtyPlates[_dirtyPlates.Count - 1];
            _dirtyPlates.RemoveAt(_dirtyPlates.Count - 1);

            return topPlate;
        }

        public Plate GetCleanPlate()
        {
            if (_dirtyPlates.Count > 0)
            {
                Plate plate = _dirtyPlates[0];
                _dirtyPlates.RemoveAt(0);
                plate.Clean();
                return plate;
            }
            return null;
        }

        public void ResetDishTray()
        {
            foreach (var coroutine in _returnPlateCoroutines)
            {
                if (coroutine != null)
                {
                    StopCoroutine(coroutine);
                }
            }
            _returnPlateCoroutines.Clear();

            foreach (var plate in _dirtyPlates)
            {
                if (plate != null)
                {
                    plate.ResetObject();
                }
            }
            _dirtyPlates.Clear();
        }

        public void StartReturnPlateCoroutine(Plate plate, float delay)
        {
            var coroutine = StartCoroutine(ReturnPlateDirty(plate, delay));
            _returnPlateCoroutines.Add(coroutine);
        }

        private IEnumerator ReturnPlateDirty(Plate plate, float delay)
        {
            yield return new WaitForSeconds(delay);
            AddDirtyPlate(plate);
        }

        public new void ResetObject()
        {
            ResetDishTray();
        }
    }
}

/*
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Undercooked.Model;
using UnityEngine;

namespace Undercooked.Appliances
{
    public class DishTray : Interactable, IResettable
    {
        private  List<Plate> _dirtyPlates = new List<Plate>();
        private List<Coroutine> _returnPlateCoroutines = new List<Coroutine>();
        public override bool TryToDropIntoSlot(IPickable pickableToDrop) => false;
        // Static instance property
        public static DishTray Instance { get; private set; }


        private void Awake()
        {
            // Ensure that there is only one instance of this class in the scene
            if (Instance == null)
            {
                Instance = this;
                // Optionally, persist this instance across scene loads
                // DontDestroyOnLoad(gameObject);
            }
            else
            {
                Destroy(gameObject);
            }
        }

        //Modified Code for ResetNewEpisoded
        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            if (_dirtyPlates.Count > 0)
            {
                var plate = _dirtyPlates[0]; // Retrieve the first dirty plate
                _dirtyPlates.RemoveAt(0); // Remove it from the list

                return plate;
            }

            return null;
        }


        //NEW VERSION OF PLATE PILE
        public void AddDirtyPlate(Plate plate)
        {
            // Ensure the plate is set to a dirty state
            plate.SetDirty();

            // Reset plate's local rotation and scale to default (in case they were altered elsewhere)
            plate.transform.localRotation = Quaternion.identity;
            plate.transform.localScale = Vector3.one;

            if (_dirtyPlates.Count > 0)
            {
                // Position the new plate slightly above the last plate in the list
                var lastPlate = _dirtyPlates[_dirtyPlates.Count - 1];
                plate.transform.position = lastPlate.transform.position + new Vector3(0, 0.1f, 0); // Adjust Y offset as needed
            }
            else
            {
                // If this is the first plate, position it at the designated slot or a specific position relative to the DishTray
                plate.transform.position = transform.position + new Vector3(0, 0.3f, 0); // Adjust initial position as needed
            }

            // Parent the plate to the DishTray or a specific child transform meant to hold the plates
            plate.transform.SetParent(transform, true);

            // Add the plate to the list of dirty plates
            _dirtyPlates.Add(plate);
        }
        public Plate GetTopPlate()
        {
            if (_dirtyPlates.Count == 0) return null;

            var topPlate = _dirtyPlates[_dirtyPlates.Count - 1];
            _dirtyPlates.RemoveAt(_dirtyPlates.Count - 1);

            // Optionally, adjust positions of remaining plates

            return topPlate;
        }

        public Plate GetCleanPlate()
        {
            if (_dirtyPlates.Count > 0)
            {
                Plate plate = _dirtyPlates[0];
                _dirtyPlates.RemoveAt(0);
                plate.Clean();
                return plate;
            }
            return null;
        }
        public void ResetDishTray()
        {
            foreach (var coroutine in _returnPlateCoroutines)
            {
                if (coroutine != null)
                {
                    StopCoroutine(coroutine);
                }
            }
            _returnPlateCoroutines.Clear();

            foreach (var plate in _dirtyPlates)
            {
                if (plate != null)
                {
                    plate.ResetObject();
                }
            }
            _dirtyPlates.Clear();
        }
        public void StartReturnPlateCoroutine(Plate plate, float delay)
        {
            var coroutine = StartCoroutine(ReturnPlateDirty(plate, delay));
            _returnPlateCoroutines.Add(coroutine);
        }

        private IEnumerator ReturnPlateDirty(Plate plate, float delay)
        {
            yield return new WaitForSeconds(delay);
            AddDirtyPlate(plate);
        }

        public new void ResetObject()
        {
            ResetDishTray();
        }
    }
}
*/