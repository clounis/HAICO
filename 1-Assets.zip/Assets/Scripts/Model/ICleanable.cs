using UnityEngine;

namespace Undercooked.Model
{
    public interface ICleanable
    {
        void Clean();
    }
}