using Undercooked.Data;
using UnityEngine;

namespace Undercooked.Model
{
    [RequireComponent(typeof(MeshFilter))]
    [RequireComponent(typeof(Rigidbody))]
    [RequireComponent(typeof(Collider))]
    public class Ingredient : Interactable, IPickable
    {
        [SerializeField] private IngredientData data;
        private Rigidbody _rigidbody;
        private Collider _collider;
        private MeshRenderer _meshRenderer;
        private MeshFilter _meshFilter;

        public IngredientStatus Status { get; private set; }
        public IngredientType Type => data.type;
        public Color BaseColor => data.baseColor;

        [SerializeField] private IngredientStatus startingStatus = IngredientStatus.Raw;
        public bool IsBeingHeld { get; private set; } = false;
        public float ProcessTime => data.processTime;
        public float CookTime => data.cookTime;
        public Sprite SpriteUI => data.sprite;

        // FOR AGENT NEW EPISODE
        public bool IsDestroyed { get; private set; } = false;




        private void OnDestroy()
        {
            IsDestroyed = true;
            Debug.Log($"{gameObject.name} is being destroyed.");
        }

        // END OF AGENT NEW EPISODE NEW METHODS

        protected override void Awake()
        {
            base.Awake();
            
            _meshRenderer = GetComponent<MeshRenderer>();
            _meshFilter = GetComponent<MeshFilter>();
            _rigidbody = GetComponent<Rigidbody>();
            _collider = GetComponent<Collider>();
            Setup();
        }

        private void Setup()
        {
            // Rigidbody is kinematic almost all the time, except when we drop it on the floor
            // re-enabling when picked up.
            _rigidbody.isKinematic = true;
            _collider.enabled = false;

            IsBeingHeld = true; //added for helping destroying ingredients

            Status = IngredientStatus.Raw;
            _meshFilter.mesh = data.rawMesh;
            _meshRenderer.material = data.ingredientMaterial;

            if (startingStatus == IngredientStatus.Processed)
            {
                ChangeToProcessed();
            }
        }

 

        public void Pick()
        {
            _rigidbody.isKinematic = true;
            _collider.enabled = false;
        }
        
        public void Drop()
        {
            gameObject.transform.SetParent(null);
            _rigidbody.isKinematic = false;
            _collider.enabled = true;
            IsBeingHeld = false; //added for helping destroying ingredients


        }

        public void ChangeToProcessed()
        {
            Status = IngredientStatus.Processed;
            _meshFilter.mesh = data.processedMesh;
        }

        public void ChangeToCooked()
        {
            Status = IngredientStatus.Cooked;
            var cookedMesh = data.cookedMesh;
            if (cookedMesh == null) return;
            
            _meshFilter.mesh = cookedMesh;
            SetMeshRendererEnabled(true);
        }

        public void SetMeshRendererEnabled(bool enable)
        {
            _meshRenderer.enabled = enable;
        }

        public override bool TryToDropIntoSlot(IPickable pickableToDrop)
        {
            if (pickableToDrop == null || ReferenceEquals(pickableToDrop, null))
            {
                Debug.LogWarning("Attempted to drop a null or destroyed pickable into the slot.");
                return false;
            }
            // Ingredients normally don't get any pickables dropped into it.
            // Debug.Log("[Ingredient] TryToDrop into an Ingredient isn't possible by design");
            return false;
        }

        public override IPickable TryToPickUpFromSlot(IPickable playerHoldPickable)
        {
            // Debug.Log($"[Ingredient] Trying to PickUp {gameObject.name}");
            _rigidbody.isKinematic = true;
            return this;
        }
    }
}