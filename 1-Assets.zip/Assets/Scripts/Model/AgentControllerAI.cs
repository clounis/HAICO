using Undercooked.Model;

public interface AgentControllerAI
{
    void InteractWithAI(Interactable interactable);
   /* void StartChopping();

    void StopChopping();

    void StartCleaning();

    void StopCleaning();
    */
}