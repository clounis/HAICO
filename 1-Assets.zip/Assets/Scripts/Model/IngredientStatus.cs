namespace Undercooked.Model
{
    public enum IngredientStatus
    {
        Raw,
        Processed,
        Cooked
    }
}