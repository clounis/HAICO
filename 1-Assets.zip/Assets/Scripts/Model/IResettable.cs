namespace Undercooked.Model
{
    public interface IResettable
    {
        void ResetObject();
    }
}