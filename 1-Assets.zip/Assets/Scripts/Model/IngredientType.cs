namespace Undercooked.Model
{
    public enum IngredientType
    {
        Onion,
        Tomato,
        Mushroom,
      //  Meat,
       // Lettuce,
       // Bun
    }
}