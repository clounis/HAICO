using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DaltonLima.Core;
using Undercooked.Appliances;
using Undercooked.Data;
using Undercooked.Model;
using Undercooked.Player;
using Undercooked.UI;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

namespace Undercooked.Managers
{
    [RequireComponent(typeof(OrderManager))]
    public class GameManager : Singleton<GameManager>
    {
        [SerializeField] private DishTray dishTray;
        [SerializeField] private DeliverCountertop deliverCountertop;
        [SerializeField] private OrderManager orderManager;
        [SerializeField] private LevelData level1;
        [SerializeField] private CameraManager cameraManager;
        [SerializeField] private InputController inputController;
        [SerializeField] private PlayerInput playerInput;
        [SerializeField] private OrdersPanelUI ordersPanelUI;
        [SerializeField] private PlayerController playerController;
        [SerializeField] private CookerAgent cookerAgent;
        [SerializeField] private OrderUI orderUI;
        [SerializeField] private Plate[] allPlates; // Assign in inspector or find dynamically
        public CookingPot cookingPot; // Reference to the CookingPot
        public Sink sink;
        private List<ChoppingBoard> choppingBoards; //Reference to ChoppingBoard
        private const int BaseScorePerPlate = 20;
        private const int PenaltyExpiredScore = 0; //10
        private const float TimeToReturnPlateSeconds = 0f;
        private List<Coroutine> _returnPlateDirtyCoroutines = new List<Coroutine>();
        private bool isResetting = false;
        private bool _timeToReturnPlateElapsed = false;

        private Coroutine _countdownCoroutine;
        private readonly WaitForSeconds _timeToReturnPlate = new WaitForSeconds(TimeToReturnPlateSeconds);
        private readonly WaitForSeconds _oneSecondWait = new WaitForSeconds(1f);
        private static int _score;
        private int _timeRemaining;
        public List<Plate> plates; // Assuming this is declared in your GameManager

        public List<IResettable> resettableObjects;

        public static int Score
        {
            get => _score;
            private set
            {
                var previous = _score;
                _score = value;
                OnScoreUpdate?.Invoke(_score, _score - previous);
            }
        }

        public int TimeRemaining
        {
            get => _timeRemaining;
            private set
            {
                _timeRemaining = value;
                OnCountdownTick?.Invoke(_timeRemaining);
            }
        }

        public static LevelData LevelData => Instance.level1;

        public delegate void CountdownTick(int timeRemaining);
        public static event CountdownTick OnCountdownTick;
        public delegate void ScoreUpdate(int score, int delta);
        public static event ScoreUpdate OnScoreUpdate;
        public delegate void DisplayNotification(string textToDisplay, Color color, float timeToDisplay);
        public static event DisplayNotification OnDisplayNotification;
        public delegate void TimeIsOver();
        public static event TimeIsOver OnTimeIsOver;
        public delegate void LevelStart();
        public static event LevelStart OnLevelStart;

        private void Awake()
        {
#if UNITY_EDITOR
            Assert.IsNotNull(dishTray);
            Assert.IsNotNull(orderManager);
            Assert.IsNotNull(level1);
            Assert.IsNotNull(cameraManager);
            Assert.IsNotNull(inputController);
#endif
            if (choppingBoards == null || choppingBoards.Count == 0)
            {
                choppingBoards = FindObjectsOfType<ChoppingBoard>().ToList();
            }

            resettableObjects = new List<IResettable>(FindObjectsOfType<MonoBehaviour>().OfType<IResettable>());
        }

        private void Start()
        {
            GameLoop();
        }

        private void GameLoop()
        {
            StartLevelAsync(level1);
        }

        private bool _userPressedStart;

        private async Task StartMainMenuAsync()
        {
            await Task.Delay(1000);
            MenuPanelUI.InitialMenuSetActive(true);
            cameraManager.SwitchDollyCamera();

            inputController.EnableMenuControls();
            inputController.OnStartPressedAtMenu += HandleStartAtMenu;

            while (_userPressedStart == false)
            {
                await Task.Delay(1000);
            }
            MenuPanelUI.InitialMenuSetActive(false);
            inputController.OnStartPressedAtMenu -= HandleStartAtMenu;
        }

        private void HandleStartAtMenu()
        {
            _userPressedStart = true;
        }

        private async Task StartLevelAsync(LevelData levelData)
        {
            cameraManager.FocusFirstPlayer();

            Score = 0;
            _timeRemaining = levelData.durationTime;

            orderManager.Init(levelData);

            OnLevelStart?.Invoke();

            inputController.EnableGameplayControls();
            inputController.EnableFirstPlayerController();

            inputController.OnStartPressedAtPlayer += HandlePausePressed;

            _countdownCoroutine = StartCoroutine(CountdownTimer(_timeRemaining));

            PositionCookingPotOnHob();
        }

        private void HandlePausePressed()
        {
            MenuPanelUI.PauseUnpause();
        }

        private void OnEnable()
        {
            DeliverCountertop.OnPlateDropped += HandlePlateDropped;
            OrderManager.OnOrderExpired += HandleOrderExpired;
            OrderManager.OnOrderDelivered += HandleOrderDelivered;

            MenuPanelUI.OnQuitButton += HandleQuitButton;
            MenuPanelUI.OnRestartButton += HandleRestartButton;
            MenuPanelUI.OnResumeButton += HandleResumeButton;
        }

        private void OnDisable()
        {
            DeliverCountertop.OnPlateDropped -= HandlePlateDropped;
            OrderManager.OnOrderExpired -= HandleOrderExpired;
            OrderManager.OnOrderDelivered -= HandleOrderDelivered;

            MenuPanelUI.OnQuitButton -= HandleQuitButton;
            MenuPanelUI.OnRestartButton -= HandleRestartButton;
            MenuPanelUI.OnResumeButton -= HandleResumeButton;
        }

        private static void HandleResumeButton()
        {
            MenuPanelUI.PauseUnpause();
        }

        private void HandleRestartButton()
        {
            int sceneIndex = SceneManager.GetActiveScene().buildIndex;
            SceneManager.LoadScene(sceneIndex);
        }

        private static void HandleQuitButton()
        {
            Application.Quit();
        }

        private void HandleOrderDelivered(Order order, int tipCalculated)
        {
            Debug.Log($"Order delivered: {order}, tip: {tipCalculated}");
            Score += BaseScorePerPlate;
        }

        private void HandleOrderExpired(Order order)
        {
            // Handle order expired logic
        }

        public void Pause()
        {
            MenuPanelUI.PauseUnpause();
        }

        public void Unpause()
        {
            MenuPanelUI.PauseUnpause();
        }

        private void HandlePlateDropped(Plate plate)
        {
            if (plate.IsEmpty() || !plate.IsClean)
            {
                plate.RemoveAllIngredients();
                StartReturnPlateDirtyCoroutine(plate, TimeToReturnPlateSeconds);
                return;
            }

            orderManager.CheckIngredientsMatchOrder(plate.Ingredients);
            plate.RemoveAllIngredients();
            StartReturnPlateDirtyCoroutine(plate, TimeToReturnPlateSeconds);
        }

        private void StartReturnPlateDirtyCoroutine(Plate plate, float delay)
        {
            var coroutine = StartCoroutine(ReturnPlateDirty(plate, delay));
            _returnPlateDirtyCoroutines.Add(coroutine);
        }

        private IEnumerator ReturnPlateDirty(Plate plate, float delay)
        {
            float elapsedTime = 0;
            while (elapsedTime < delay)
            {
                if (isResetting)
                {
                    yield break;
                }
                yield return new WaitForSeconds(0.1f);
                elapsedTime += 0.1f;
            }

            if (!isResetting)
            {
                plate.SetDirty();
                dishTray.AddDirtyPlate(plate);
            }
        }

        public void StopAndClearReturnPlateDirtyCoroutines()
        {
            foreach (var coroutine in _returnPlateDirtyCoroutines)
            {
                if (coroutine != null)
                {
                    StopCoroutine(coroutine);
                }
            }
            _returnPlateDirtyCoroutines.Clear();
        }

        private IEnumerator CountdownTimer(int timeInSeconds)
        {
            var timeRemaining = timeInSeconds;
            while (timeRemaining > 0)
            {
                timeRemaining--;
                yield return _oneSecondWait;
                OnCountdownTick?.Invoke(timeRemaining);
            }
        }

        public void ResetPlates()
        {
            if (plates == null)
            {
                Debug.LogError("GameManager: Plates list is null.");
                return;
            }
            foreach (var plate in plates)
            {
                if (plate == null)
                {
                    Debug.LogError("GameManager: A plate in the list is null.");
                    continue;
                }
            }
        }

        void DestroyAllIngredients()
        {
            Ingredient[] ingredients = FindObjectsOfType<Ingredient>();
            foreach (var ingredient in ingredients)
            {
                Destroy(ingredient.gameObject);
            }
        }

        public void ResetGame()
        {
            foreach (var plate in allPlates)
            {
                plate.ResetObject();
            }
            dishTray.ResetDishTray();
        }

        public void ResetAndRestartLevel()
        {
            isResetting = true;

            cookerAgent.ResetAgent();
            playerController.ClearAgentSlot();

            foreach (var resettable in resettableObjects)
            {
                resettable.ResetObject();
            }

            if (DishTray.Instance != null)
            {
                DishTray.Instance.ResetDishTray();
            }

            cookingPot.ResetCookingPot();
            sink.ResetDirtySlots();
            foreach (var choppingBoard in choppingBoards)
            {
                choppingBoard.ResetChoppingBoard();
            }

            StopAndClearReturnPlateDirtyCoroutines();

            orderManager.StopAndClearOrders();
            ordersPanelUI.ClearOrdersUI();
            orderManager.StartOrderGeneration();
            PositionCookingPotOnHob();

            isResetting = false;
            DestroyAllIngredients();
        }

        private void PositionCookingPotOnHob()
        {
            cookingPot.transform.position = cookingPot.defaultHobSlot.position;
            cookingPot.transform.rotation = cookingPot.defaultHobSlot.rotation;
            cookingPot.transform.SetParent(cookingPot.defaultHobSlot);
            cookingPot.DroppedIntoHob();
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.P))
            {
                ResetAndRestartLevel();
            }
        }
    }
}

/*
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DaltonLima.Core;
using Undercooked.Appliances;
using Undercooked.Data;
using Undercooked.Model;
using Undercooked.Player;
using Undercooked.UI;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

namespace Undercooked.Managers
{
    [RequireComponent(typeof(OrderManager))]
    public class GameManager : Singleton<GameManager>
    {
        [SerializeField] private DishTray dishTray;
        [SerializeField] private DeliverCountertop deliverCountertop;
        [SerializeField] private OrderManager orderManager;
        [SerializeField] private LevelData level1;
        [SerializeField] private CameraManager cameraManager;
        [SerializeField] private InputController inputController;
        [SerializeField] private PlayerInput playerInput;
        [SerializeField] private OrdersPanelUI ordersPanelUI;
        [SerializeField] private PlayerController playerController;
        [SerializeField] private CookerAgent cookerAgent;
        [SerializeField] private OrderUI orderUI;
        [SerializeField] private Plate[] allPlates; // Assign in inspector or find dynamically
        public CookingPot cookingPot; // Reference to the CookingPot
        public Sink sink;
        private List<ChoppingBoard> choppingBoards; //Reference to ChoppingBoard
      //  private List<Plate> plates; // Assuming you drag and drop your plate references in the Inspector
        private const int BaseScorePerPlate = 20;
        private const int PenaltyExpiredScore = 0; //10
        private const float TimeToReturnPlateSeconds = 0f;
        // FOR NEW EPISODE PURPOSE 
        private List<Coroutine> _returnPlateDirtyCoroutines = new List<Coroutine>();
        private bool isResetting = false;
        private bool _timeToReturnPlateElapsed = false;

        private Coroutine _countdownCoroutine;
        private readonly WaitForSeconds _timeToReturnPlate = new WaitForSeconds(TimeToReturnPlateSeconds);
        private readonly WaitForSeconds _oneSecondWait = new WaitForSeconds(1f);
        private static int _score;
        private int _timeRemaining;
        public List<Plate> plates; // Assuming this is declared in your GameManager

        // Example list of resettable objects in the scene, populate this appropriately
        public List<IResettable> resettableObjects;

        public static int Score
        {
            get => _score;
            private set
            {
                var previous = _score;
                _score = value;
                OnScoreUpdate?.Invoke(_score, _score - previous);
            }
        }

        public int TimeRemaining
        {
            get => _timeRemaining;
            private set
            {
                _timeRemaining = value;
                OnCountdownTick?.Invoke(_timeRemaining);
            }
        }

        public static LevelData LevelData => Instance.level1; 

        public delegate void CountdownTick(int timeRemaining);
        public static event CountdownTick OnCountdownTick;
        public delegate void ScoreUpdate(int score, int delta);
        public static event ScoreUpdate OnScoreUpdate;
        public delegate void DisplayNotification(string textToDisplay, Color color, float timeToDisplay);
        public static event DisplayNotification OnDisplayNotification;
        public delegate void TimeIsOver();
        public static event TimeIsOver OnTimeIsOver;
        public delegate void LevelStart();
        public static event LevelStart OnLevelStart;
        
        private void Awake()
        {
            #if UNITY_EDITOR
                Assert.IsNotNull(dishTray);
                Assert.IsNotNull(orderManager);
                Assert.IsNotNull(level1);
                Assert.IsNotNull(cameraManager);
                Assert.IsNotNull(inputController);
#endif
            if (choppingBoards == null || choppingBoards.Count == 0)
            {
                choppingBoards = FindObjectsOfType<ChoppingBoard>().ToList();
            }

            // Initialize resettables list with all IResettable objects in the scene
            // This is an example and might need adjustments based on your scene setup
            resettableObjects = new List<IResettable>(FindObjectsOfType<MonoBehaviour>().OfType<IResettable>());
            // plates = new List<Plate>();
        }

        private  void Start()
        {
             GameLoop();
        }

      //  private async void Start() //DECOMMENT FOR HAVING A FULL GAME
       // {
       //     await GameLoop();
       // }

        private void OnDestroy()
        {
            _userPressedStart = true;
        }

        
       //  private async Task GameLoop() //DECOMMENT FOR HAVING A FULL GAME
         // {
          //    await StartMainMenuAsync();  // maybe move this out to Start()   //REMOVE THIS CHRIS TO HAVE A START MENU FOR YOUR EXPERIMENT
           //   await StartLevelAsync(level1);
        //  
        private void GameLoop()
        {
            StartLevelAsync(level1);  // Assuming StartLevelAsync was renamed to StartLevel and is no longer asynchronous.
        }


        private bool _userPressedStart;
        
        private async Task StartMainMenuAsync()
        {
            await Task.Delay(1000);
            MenuPanelUI.InitialMenuSetActive(true);
            cameraManager.SwitchDollyCamera();
            
            // activate MenuControls
            inputController.EnableMenuControls();
            inputController.OnStartPressedAtMenu += HandleStartAtMenu;
            
            while (_userPressedStart == false)
            {
                await Task.Delay(1000);
            }
            MenuPanelUI.InitialMenuSetActive(false);
            inputController.OnStartPressedAtMenu -= HandleStartAtMenu;
        }
       
        private void HandleStartAtMenu()
        {
            _userPressedStart = true;
        }
       
        private async Task StartLevelAsync(LevelData levelData)
        {
            //_startAtMenuAction = playerInput.currentActionMap["Start@Menu"];
            // _startAtMenuAction.performed += HandleStart;
            
            cameraManager.FocusFirstPlayer();
            
            Score = 0;
            _timeRemaining = levelData.durationTime;
            
          //  await DisplayInitialNotifications();  //A DE COMMENTER BESOIN DU MESSAGE DE TOP DEPART INITIAL
            orderManager.Init(levelData);

            OnLevelStart?.Invoke();
            // Unlock player movement
            inputController.EnableGameplayControls();
            inputController.EnableFirstPlayerController();

            inputController.OnStartPressedAtPlayer += HandlePausePressed;
            
            _countdownCoroutine = StartCoroutine(CountdownTimer(_timeRemaining));

            // Ensure the cooking pot is correctly positioned on the hob at the start of the level
            PositionCookingPotOnHob();
            //TODO: handle pause (pause timer coroutine and restart)
        }



        private void HandlePausePressed()
        {
            MenuPanelUI.PauseUnpause();
        }

        private InputAction _startAtPlayerAction;
        private bool _hasSubscribedPlayerActions;
        private bool _hasSubscribedMenuActions;
        
   
    //    private static async Task DisplayInitialNotifications()
     //   {
      //      await NotificationUI.DisplayCenterNotificationAsync("Ready?", new Color(.66f, .367f, .15f), 2f);
       //     await NotificationUI.DisplayCenterNotificationAsync("GO", new Color(.333f, .733f, .196f), 2f);
      // }
      
        private void OnEnable()
        {
            DeliverCountertop.OnPlateDropped += HandlePlateDropped;
            OrderManager.OnOrderExpired += HandleOrderExpired;
            OrderManager.OnOrderDelivered += HandleOrderDelivered;

            MenuPanelUI.OnQuitButton += HandleQuitButton;
            MenuPanelUI.OnRestartButton += HandleRestartButton;
            MenuPanelUI.OnResumeButton += HandleResumeButton;
        }

        private void OnDisable()
        {
            DeliverCountertop.OnPlateDropped -= HandlePlateDropped;
            OrderManager.OnOrderExpired -= HandleOrderExpired;
            OrderManager.OnOrderDelivered -= HandleOrderDelivered;
            
            MenuPanelUI.OnQuitButton -= HandleQuitButton;
            MenuPanelUI.OnRestartButton -= HandleRestartButton;
            MenuPanelUI.OnResumeButton -= HandleResumeButton;
        }

        private static void HandleResumeButton()
        {
            MenuPanelUI.PauseUnpause();
        }

        private void HandleRestartButton()
        {
            //Start();
            int sceneIndex = SceneManager.GetActiveScene().buildIndex;
            //SceneManager.UnloadSceneAsync(sceneIndex);
            SceneManager.LoadScene(sceneIndex);
        }

        private static void HandleQuitButton()
        {
            Application.Quit();
        }

        private void HandleOrderDelivered(Order order, int tipCalculated)
        {
            Debug.Log($"Order delivered: {order}, tip: {tipCalculated}");
             Score += BaseScorePerPlate; // + tipCalculated;
        }
        
        private void HandleOrderExpired(Order order)
        {
            //Score -= PenaltyExpiredScore;
        }

        public void Pause()
        {
            // player controller ignore input
            //Time.timeScale = 0;
            MenuPanelUI.PauseUnpause();
            //StopCoroutine(_countdownCoroutine);
        }

        public void Unpause()
        {
            // restore player input (event?)
            //Time.timeScale = 1;
            MenuPanelUI.PauseUnpause();
            //_countdownCoroutine = StartCoroutine(CountdownTimer(_timeRemaining));
        }

        private void HandlePlateDropped(Plate plate)
        {
            if (plate.IsEmpty() || plate.IsClean == false)
            {
                plate.RemoveAllIngredients();
                StartReturnPlateDirtyCoroutine(plate, TimeToReturnPlateSeconds);
                return;
            }

            orderManager.CheckIngredientsMatchOrder(plate.Ingredients);
            plate.RemoveAllIngredients();
            StartReturnPlateDirtyCoroutine(plate, TimeToReturnPlateSeconds);
        }

        private void StartReturnPlateDirtyCoroutine(Plate plate, float delay)
        {
            var coroutine = StartCoroutine(ReturnPlateDirty(plate, delay));
            _returnPlateDirtyCoroutines.Add(coroutine);
        }

        private IEnumerator ReturnPlateDirty(Plate plate, float delay)
        {
            float elapsedTime = 0;
            while (elapsedTime < delay)
            {
                if (isResetting)
                {
                    yield break;
                }
                yield return new WaitForSeconds(0.1f);
                elapsedTime += 0.1f;
            }

            if (!isResetting)
            {
                plate.SetDirty();
                dishTray.AddDirtyPlate(plate);
            }
        }

        //FOR RESETTING PURPOSE
        public void StopAndClearReturnPlateDirtyCoroutines()
        {
            foreach (var coroutine in _returnPlateDirtyCoroutines)
            {
                if (coroutine != null)
                {
                    StopCoroutine(coroutine);
                }
            }
            _returnPlateDirtyCoroutines.Clear();
        }



        private IEnumerator CountdownTimer(int timeInSeconds)
        {
            var timeRemaining = timeInSeconds;
            while (timeRemaining > 0)
            {
                timeRemaining--;
                yield return _oneSecondWait;
                OnCountdownTick?.Invoke(timeRemaining);
            }

            //TimeOver();  //DECOMMENT THIS TO HAVE A CLOCK IN YOUR EXPERIMENT
        }



        public void ResetPlates()
        {
            if (plates == null)
            {
                Debug.LogError("GameManager: Plates list is null.");
                return;
            }
            foreach (var plate in plates)
            {
                if (plate == null)
                {
                    Debug.LogError("GameManager: A plate in the list is null.");
                    continue;
                }
            //  plate.ResetPlate();
            }
        }

        void DestroyAllIngredients()
        {
            Ingredient[] ingredients = FindObjectsOfType<Ingredient>();
            foreach (var ingredient in ingredients)
            {
                Destroy(ingredient.gameObject);
                //ingredient.gameObject.SetActive(false);

            }
        }


        public void ResetGame()
        {
            foreach (var plate in allPlates)
            {
                plate.ResetObject();
            }
            dishTray.ResetDishTray();
            // Reset other game elements as needed
        }

        // Method to start a ReturnPlateDirty coroutine and keep track of it

        // Method to stop all ReturnPlateDirty coroutines

        public void ResetAndRestartLevel()
        {
            // Signal that a reset is taking place
            isResetting = true;

            // Ensure the agent releases any held objects properly
            // InteractableController.ResetAllInteractables();
            cookerAgent.ResetAgent(); //DONE IN THE COOKER AGENT
            playerController.ClearAgentSlot();

            // Reset all IResettable objects

            foreach (var resettable in resettableObjects)
            {
                resettable.ResetObject();
            }

            // Ensure the DishTray is properly reset
            if (DishTray.Instance != null)
            {
                DishTray.Instance.ResetDishTray();
            }


            // Additional clean-up for specific components if they are not part of resettables
            cookingPot.ResetCookingPot();
            sink.ResetDirtySlots();
            foreach (var choppingBoard in choppingBoards)
            {
                choppingBoard.ResetChoppingBoard();
            }

            // Destroy all ingredients after ensuring they are no longer referenced
            
            // Resetting the game environment
            // ResetGame(); // This should include resetting plates, scores, timers, etc.

            // Stop and clear any coroutines related to gameplay
            StopAndClearReturnPlateDirtyCoroutines();

            // Prepare the game for a new episode or level
            orderManager.StopAndClearOrders();
            ordersPanelUI.ClearOrdersUI();
            orderManager.StartOrderGeneration();
            PositionCookingPotOnHob();
            // Signal the end of the reset
            isResetting = false;
            //SceneManager.LoadScene(SceneManager.GetActiveScene().name);

            // Optionally start a new game loop or level
            // GameLoop();
            DestroyAllIngredients();
          

        }
        private void PositionCookingPotOnHob()
        {
            // Ensure the cooking pot is positioned correctly on the hob
            cookingPot.transform.position = cookingPot.defaultHobSlot.position;
            cookingPot.transform.rotation = cookingPot.defaultHobSlot.rotation;
            cookingPot.transform.SetParent(cookingPot.defaultHobSlot);

            // Ensure the cooking pot is in the correct state to accept ingredients
            cookingPot.DroppedIntoHob();
        }
       private void Update() // FOR TESTING PURPOSE ONLY
        {
            // Check if a specific key is pressed, for example, the R key
            if (Input.GetKeyDown(KeyCode.P))
            {
                ResetAndRestartLevel();
            }
        }
      
       
    }
}
*/