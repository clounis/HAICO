using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Undercooked.Data;
using Undercooked.Model;
using Undercooked.UI;
using UnityEngine;
using Random = UnityEngine.Random;

namespace Undercooked.Managers
{
    public class OrderManager : MonoBehaviour
    {

        [SerializeField] private LevelData currentLevel;
        [SerializeField] private Order orderPrefab;
        [SerializeField] private float spawnIntervalBetweenOrders = 15f;
        [SerializeField] private float extraTimePerOrder = 20f;
        [SerializeField] private int maxConcurrentOrders = 5;
        [SerializeField] private OrdersPanelUI ordersPanelUI;

        private readonly List<Order> _orders = new List<Order>();
        private readonly Queue<Order> _poolOrders = new Queue<Order>();

        private WaitForSeconds _intervalBetweenDropsWait;
        private bool _isGeneratorActive;
        private Coroutine _generatorCoroutine;
        
        public delegate void OrderSpawned(Order order);
        public static event OrderSpawned OnOrderSpawned;

        public delegate void OrderExpired(Order order);
        public static event OrderExpired OnOrderExpired;
        
        public delegate void OrderDelivered(Order order, int tipCalculated);
        public static event OrderDelivered OnOrderDelivered;

        private Order GetOrderFromPool()
        {
            return _poolOrders.Count > 0 ? _poolOrders.Dequeue() : Instantiate(orderPrefab, transform);
        }
        
        public void Init(LevelData levelData)
        {
            currentLevel = levelData;
            _orders.Clear();
            _intervalBetweenDropsWait = new WaitForSeconds(spawnIntervalBetweenOrders);
            _isGeneratorActive = true;
            _generatorCoroutine = StartCoroutine(OrderGeneratorCoroutine());
        }

        private void PauseOrderGenerator()
        {
            _isGeneratorActive = false;
            if (_generatorCoroutine != null)
            {
                StopCoroutine(_generatorCoroutine);
            }
        }

        private void ResumeIfPaused()
        {
            _isGeneratorActive = true;
            _generatorCoroutine ??= StartCoroutine(OrderGeneratorCoroutine());
        }
        
        public void StopAndClear()
        {
            PauseOrderGenerator();
            _generatorCoroutine = null;
            _orders.Clear();
            
            Debug.Log("[OrderManager] StopAndClear");
        }

        private IEnumerator OrderGeneratorCoroutine()
        {
            while (_isGeneratorActive)
            {
                TrySpawnOrder();
                yield return _intervalBetweenDropsWait;    
            }
        }

        private void TrySpawnOrder()
        {
            if (_orders.Count < maxConcurrentOrders)
            {
                var order = GetOrderFromPool();
                if (order == null)
                {
                    Debug.LogWarning("[OrderManager] Couldn't pick an Order from pool", this);
                    return;
                }
                
                order.Setup(GetRandomOrderData(), _orders.Count * extraTimePerOrder);
                _orders.Add(order);
                SubscribeEvents(order);
                OnOrderSpawned?.Invoke(order);
            }
        }

        private static void SubscribeEvents(Order order)
        {
            order.OnDelivered += HandleOrderDelivered;
            order.OnExpired += HandleOrderExpired;
        }
        
        private static void UnsubscribeEvents(Order order)
        {
            order.OnDelivered -= HandleOrderDelivered;
            order.OnExpired -= HandleOrderExpired;
        }

        private static void HandleOrderDelivered(Order order)
        {
            // Debug.Log("[OrderManager] HandleOrderDelivered");
          //  OnOrderDelivered?.Invoke(order, CalculateTip(order));
        }
        
        private static void HandleOrderExpired(Order order)
        {
            // Debug.Log("[OrderManager] HandleOrderExpired");
            OnOrderExpired?.Invoke(order);
        }

        private void DeactivateSendBackToPool(Order order)
        {
            order.SetOrderDelivered();
            UnsubscribeEvents(order);
            _orders.RemoveAll(x => x.IsDelivered);
            _poolOrders.Enqueue(order);
        }

        private OrderData GetRandomOrderData()
        {
            var randomIndex = Random.Range(0, currentLevel.orders.Count);
            return Instantiate(currentLevel.orders[randomIndex]);
        }

        /*
        public void CheckIngredientsMatchOrder(List<Ingredient> ingredients)
        {
            if (ingredients == null) return;
            List<IngredientType> plateIngredients = ingredients.Select(x => x.Type).ToList();

            // orders are checked by arrival order (arrivalTime is reset when order expires)
            List<Order> orderByArrivalNotDelivered = _orders
                .Where(x => x.IsDelivered == false)
                .OrderBy(x => x.ArrivalTime).ToList();
            
            for (int i = 0; i < orderByArrivalNotDelivered.Count; i++)
            {
                var order = orderByArrivalNotDelivered[i];

                List<IngredientType> orderIngredients = order.Ingredients.Select(x => x.type).ToList();

                if (plateIngredients.Count != orderIngredients.Count) continue;
                
                var intersection = plateIngredients.Except(orderIngredients).ToList();
                
                if (intersection.Count != 0) continue; // doesn't match any plate
                
                var tip = CalculateTip(order);
                DeactivateSendBackToPool(order);
                OnOrderDelivered?.Invoke(order, tip);
                ordersPanelUI.RegroupPanelsLeft();
                return;
            }
        }
        */
        public void CheckIngredientsMatchOrder(List<Ingredient> ingredients)
        {
            if (ingredients == null) return;
            List<IngredientType> plateIngredients = ingredients.Select(x => x.Type).OrderBy(y => y).ToList();

            // orders are checked by arrival order (arrivalTime is reset when order expires)
            List<Order> orderByArrivalNotDelivered = _orders
                .Where(x => x.IsDelivered == false)
                .OrderBy(x => x.ArrivalTime).ToList();

            foreach (var order in orderByArrivalNotDelivered)
            {
                List<IngredientType> orderIngredients = order.Ingredients.Select(x => x.type).OrderBy(y => y).ToList();

                // First, we check if both the plate and the order have the same number of ingredients.
                if (plateIngredients.Count != orderIngredients.Count) continue;

                // Then we compare ingredient-by-ingredient. If they don't match, break out of the loop.
                bool isMatch = true;
                for (int i = 0; i < plateIngredients.Count; i++)
                {
                    if (plateIngredients[i] != orderIngredients[i])
                    {
                        isMatch = false;
                        break;
                    }
                }

                if (!isMatch) continue;  // Move to the next order if they don't match

                // If two orders have the same ingredients, this loop ensures the older one is matched first.
                if (_orders.Any(o => o.ArrivalTime < order.ArrivalTime && !o.IsDelivered && o.Ingredients.Select(x => x.type).OrderBy(y => y).SequenceEqual(plateIngredients)))
                {
                    continue; // If there's an older undelivered order with the same ingredients, skip to the next iteration.
                }

                // If it gets here, it means the ingredients match.
                var tip = CalculateTip(order);
                DeactivateSendBackToPool(order);
                OnOrderDelivered?.Invoke(order, tip);
                ordersPanelUI.RegroupPanelsLeft();
                return;
            }
        }
        private static int CalculateTip(Order order)
        {
            return 0;
            // var ratio = order.RemainingTime / order.InitialRemainingTime;
           // if (ratio > 0.75f) return 6;
           // if (ratio > 0.5f) return 4;
           // return ratio > 0.25f ? 2 : 0;
        }
        public List<Order> GetCurrentOrders()
        {
            var currentOrders = _orders.Where(order => !order.IsDelivered).ToList();
            Debug.Log($"[OrderManager] Fetched {currentOrders.Count} current orders.");
            return _orders.Where(order => !order.IsDelivered).ToList();
        }


        //FOR NEW EPIDSODE PURPOSE
        
        public void ResetOrdersAndStartNew()
        {
            StopAndClearOrders(); // Stop generating orders and clear existing ones
            StartOrderGeneration(); // Start generating orders as at the beginning of the game
        }

        public void StopAndClearOrders()
        {
            PauseOrderGenerator(); // Stop order generation coroutine
            foreach (var order in _orders)
            {
                if (order != null)
                {
                    UnsubscribeEvents(order); // Unsubscribe from events to prevent memory leaks
                    Destroy(order.gameObject); // Destroy the order GameObject
                }
            }
            _orders.Clear(); // Clear the list of orders
        }

        public void StartOrderGeneration()
        {
            _isGeneratorActive = true; // Enable order generation
            _generatorCoroutine = StartCoroutine(OrderGeneratorCoroutine()); // Start the order generation coroutine
        }
        
    }


}
