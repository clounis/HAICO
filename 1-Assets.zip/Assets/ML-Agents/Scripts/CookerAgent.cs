
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;
using UnityEngine.AI;
using System.Collections.Generic;
using System.Linq;
using Undercooked.Appliances;
using Undercooked.Managers;
using Undercooked.Model;
using Undercooked.Player;
using UnityEngine.InputSystem;
using System.IO;

public class CookerAgent : Agent
{
    #region Serialized Fields
    [SerializeField] private Transform slot;
    [SerializeField] private Transform Human_slot;
    [SerializeField] public Sink sink;
    [SerializeField] public OrderManager orderManager;
    [SerializeField] public GameManager gameManager;
    public GameObject IngredientCrate_Onion_01;
    public GameObject IngredientCrate_Onion;
    public GameObject ChoppingBoard_Countetop1;
    public GameObject ChoppingBoard_Countetop2;
    public GameObject Hob;
    public GameObject Plate1;
    public GameObject Plate2;
    public GameObject DeliverCountertop;
    public CookingPot cookingPot;
    private List<ChoppingBoard> choppingBoards;
    private List<Hob> hobs;
    private NavMeshAgent navMeshAgent;
    public ChoppingBoard currentChoppingBoard;
    public PlayerController _playerController;
    private Coroutine _currentActionCoroutine;
    public IPickable _currentPickable;
    [SerializeField] private PlayerInput playerInput;
    private InputAction _moveAction;
    public InputAction _pickUpAction;
    private InputAction _interactAction;
    [SerializeField] private Animator animator;
    private readonly int _isCleaningHash = Animator.StringToHash("isCleaning");
    private readonly int _hasPickupHash = Animator.StringToHash("hasPickup");
    private readonly int _isChoppingHash = Animator.StringToHash("isChopping");
    private Vector3 initialPosition;
    private Quaternion initialRotation;
    public InteractableController _interactableController;
    private StreamWriter logFile; //for saving agent action
    #endregion

    private const int MaxStepsPerEpisode = 36000;

    private void Start()
    {
        //FOR FOLLOWING ACTION TAKE BY THE AI
        logFile = new StreamWriter("AgentActionsLog.txt", true);
        logFile.WriteLine("Starting new session...");

        navMeshAgent = GetComponent<NavMeshAgent>();
        choppingBoards = FindObjectsOfType<ChoppingBoard>().ToList();
        MaxStep = MaxStepsPerEpisode;
        _interactableController = GetComponentInChildren<InteractableController>();

        if (_playerController == null)
        {
            _playerController = GetComponent<PlayerController>();
            if (_playerController == null)
            {
                Debug.LogError("PlayerController component is not found on the object.");
            }
        }

        if (animator == null)
        {
            animator = GetComponent<Animator>();
            if (animator == null)
            {
                Debug.LogError("Animator component is not found on the object.");
            }
        }
    }

    private void OnDestroy()
    {
        logFile.Close();
    }

    private void Awake()
    {
        initialPosition = transform.position;
        initialRotation = transform.rotation;
    }

    public override void OnEpisodeBegin()
    {
        ResetAgent();
        gameManager.ResetAndRestartLevel();
        Debug.Log("New episode started.");
    }

    public void ResetAgent()
    {
        ClearAgentSlot();

        if (animator != null)
        {
            animator.SetBool(_hasPickupHash, false);
            animator.SetBool(_isCleaningHash, false);
            animator.SetBool(_isChoppingHash, false);
        }

        transform.position = initialPosition;
        transform.rotation = initialRotation;

        if (navMeshAgent != null)
        {
            navMeshAgent.ResetPath();
            navMeshAgent.enabled = false;
            navMeshAgent.enabled = true;
        }

        Debug.Log("Agent has been reset.");
    }

    public void ClearAgentSlot()
    {
        if (_currentPickable != null)
        {
            DropItem();
       //   Destroy(_currentPickable.gameObject);  // Reset any specific state on the pickable
            _currentPickable = null;  // Clear the reference
        }

        if (slot.childCount > 0)
        {
            var ingredient = slot.GetChild(0).GetComponent<Ingredient>();
            if (ingredient != null)
            {
                Destroy(ingredient.gameObject); // Destroy the ingredient object
            }
            _currentPickable = null; // Clear the reference if using _currentPickable to track the held item
        }

        if (animator != null)
        {
            animator.SetBool(_hasPickupHash, false); // Reset animation state
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var discreteActionsOut = actionsOut.DiscreteActions;
        for (int i = 0; i < discreteActionsOut.Length; i++)
        {
            discreteActionsOut[i] = 0;
        }

        if (Input.GetKey(KeyCode.S)) discreteActionsOut[0] = (int)AgentAction.MoveToOnionCrate;
        else if (Input.GetKey(KeyCode.C)) discreteActionsOut[0] = (int)AgentAction.MoveToChoppingBoard;
        else if (Input.GetKey(KeyCode.J)) discreteActionsOut[0] = (int)AgentAction.MoveToOnionCrate_H;
        else if (Input.GetKey(KeyCode.B)) discreteActionsOut[0] = (int)AgentAction.MoveToChoppingBoard_H;
        else if (Input.GetKey(KeyCode.D)) discreteActionsOut[0] = (int)AgentAction.MoveToPlate1;
        else if (Input.GetKey(KeyCode.H)) discreteActionsOut[0] = (int)AgentAction.MoveToPlate2;
        else if (Input.GetKey(KeyCode.V)) discreteActionsOut[0] = (int)AgentAction.MoveToHob;
        else if (Input.GetKey(KeyCode.Alpha5)) discreteActionsOut[0] = (int)AgentAction.MoveToDeliver;
        else if (Input.GetKey(KeyCode.T)) discreteActionsOut[0] = (int)AgentAction.PickUp;
       // else if (Input.GetKey(KeyCode.Y)) discreteActionsOut[0] = (int)AgentAction.Clean;
        else if (Input.GetKey(KeyCode.E)) discreteActionsOut[0] = (int)AgentAction.Chop;
       // else if (Input.GetKey(KeyCode.X)) discreteActionsOut[0] = (int)AgentAction.Drop;
    }


    private SlotItem GetSlotItem(Transform slotTransform)
    {
        if (slotTransform.childCount == 0) return SlotItem.Empty;

        GameObject item = slotTransform.GetChild(0).gameObject;
        if (item.CompareTag("Tomato")) return SlotItem.Tomato;
        else if (item.CompareTag("Onion")) return SlotItem.Onion;
        else if (item.CompareTag("Mushroom")) return SlotItem.Mushroom;

        return SlotItem.Empty;
    }

    private void Update()
    {
        RewardBasedOnScoreChange();
    }

    private int previousScore = 0;
    private void RewardBasedOnScoreChange()
    {
        int currentScore = GameManager.Score;
        int scoreChange = currentScore - previousScore;

        if (scoreChange > 0)
        {
            AddReward(scoreChange);
            Debug.Log($"Rewarding agent for score increase: {scoreChange}");
        }

        previousScore = currentScore;
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        List<Order> currentOrders = orderManager.GetCurrentOrders();
        int maxOrders = 3;
        int maxIngredientsPerOrder = 3;

        for (int i = 0; i < maxOrders; i++)
        {
            if (i < currentOrders.Count)
            {
                Order order = currentOrders[i];
                sensor.AddObservation(order.RemainingTime);

                int ingredientsAdded = 0;
                foreach (var ingredient in order.Ingredients)
                {
                    sensor.AddObservation(IngredientTypeToOneHot(ingredient.type));
                    ingredientsAdded++;
                }

                for (; ingredientsAdded < maxIngredientsPerOrder; ingredientsAdded++)
                {
                    sensor.AddObservation(new float[] { 0, 0, 0 });
                }
            }
            else
            {
                sensor.AddObservation(-1f);

                for (int j = 0; j < maxIngredientsPerOrder; j++)
                {
                    sensor.AddObservation(new float[] { 0, 0, 0 });
                }
            }
        }

        SlotItem slotItem = GetSlotItem(slot);
        sensor.AddOneHotObservation((int)slotItem, System.Enum.GetNames(typeof(SlotItem)).Length);

        float remainingGameTime = GameManager.Instance.TimeRemaining;
        sensor.AddObservation(remainingGameTime);

        int currentScore = GameManager.Score;
        sensor.AddObservation((float)currentScore);

        //ObservePlateState(sensor, Plate1);
        //ObservePlateState(sensor, Plate2);

       // float cleaningTimeTotal = Sink.CleaningTime;

        //float plate1RemainingTime = sink.IsCleaningInProgress ? (1 - sink.CleaningProgress) * cleaningTimeTotal : 0;
        //float plate2RemainingTime = sink.IsCleaningInProgress ? (1 - sink.CleaningProgress) * cleaningTimeTotal : 0;

        //sensor.AddObservation(plate1RemainingTime);
        //sensor.AddObservation(plate2RemainingTime);

        //if (sink.IsCleaningInProgress)
        //{
        //    sensor.AddObservation(sink.CleaningProgress);
       // }
       // else
        //{
         //   sensor.AddObservation(0.0f);
        //}

        foreach (var choppingBoard in choppingBoards)
        {
            sensor.AddObservation(choppingBoard.IsChoppingInProgress ? 1 : 0);
            float remainingChopTime = choppingBoard.IsChoppingInProgress ? 1 - (choppingBoard.CurrentProcessTime / choppingBoard.FinalProcessTime) : 0;
            sensor.AddObservation(remainingChopTime);
        }

        float potremainingTime = cookingPot.RemainingCookTime;
        sensor.AddObservation(potremainingTime);

        foreach (var ingredient in cookingPot.Ingredients)
        {
            sensor.AddObservation(ingredient.Type == IngredientType.Onion ? 1.0f : 0.0f);
            sensor.AddObservation(ingredient.Type == IngredientType.Tomato ? 1.0f : 0.0f);
            sensor.AddObservation(ingredient.Type == IngredientType.Mushroom ? 1.0f : 0.0f);
            sensor.AddObservation((float)ingredient.Status);
        }

        for (int i = cookingPot.Ingredients.Count; i < CookingPot.MaxNumberIngredients; i++)
        {
            sensor.AddObservation(0.0f);
            sensor.AddObservation(0.0f);
            sensor.AddObservation(0.0f);
            sensor.AddObservation(0.0f);
        }
    }

    private float[] IngredientTypeToOneHot(IngredientType type)
    {
        switch (type)
        {
            case IngredientType.Onion:
                return new float[] { 1, 0, 0 };
            case IngredientType.Tomato:
                return new float[] { 0, 1, 0 };
            case IngredientType.Mushroom:
                return new float[] { 0, 0, 1 };
            default:
                return new float[] { 0, 0, 0 };
        }
    }

    /*
    private void ObservePlateState(VectorSensor sensor, GameObject plateObject)
    {
        if (plateObject == null)
        {
            sensor.AddObservation(0);
            return;
        }

        Plate plate = plateObject.GetComponent<Plate>();
        if (plate != null)
        {
            sensor.AddObservation(!plate.IsClean ? 1 : 0);
        }
        else
        {
            sensor.AddObservation(0);
        }
    }
    */

    public enum SlotItem
    {
        Empty,
        Tomato,
        Onion,
        Mushroom,
    }

    public enum AgentAction
    {
        Stay,
        MoveToOnionCrate,
        MoveToChoppingBoard,
        MoveToOnionCrate_H,
        MoveToChoppingBoard_H,
        MoveToHob,
        MoveToDeliver,
        MoveToPlate1,
        MoveToPlate2,
        PickUp,
       // Clean,
        Chop,
      //  Drop,
    }

    public override void OnActionReceived(ActionBuffers actionBuffers)
    {
        AgentAction action = (AgentAction)actionBuffers.DiscreteActions[0];

        switch (action)
        {
            case AgentAction.Stay:
                LogAction("Noop");
                break;
            case AgentAction.MoveToOnionCrate:
                LogAction("MoveToOnionCrate");
                MoveTo(IngredientCrate_Onion_01.transform.position);
                break;
            case AgentAction.MoveToChoppingBoard:
                LogAction("MoveToChoppingBoard");
                MoveTo(ChoppingBoard_Countetop1.transform.position);
                currentChoppingBoard = ChoppingBoard_Countetop1.GetComponent<ChoppingBoard>();
                break;
            case AgentAction.MoveToOnionCrate_H:
                LogAction("MoveToOnionCrate_H");
                MoveTo(IngredientCrate_Onion.transform.position);
                break;
            case AgentAction.MoveToChoppingBoard_H:
                LogAction("MoveToChoppingBoard_H");
                MoveTo(ChoppingBoard_Countetop2.transform.position);
                currentChoppingBoard = ChoppingBoard_Countetop2.GetComponent<ChoppingBoard>();
                break;
            case AgentAction.MoveToDeliver:
                LogAction("MoveToDeliver");
                MoveTo(DeliverCountertop.transform.position);
                break;
            case AgentAction.MoveToHob:
                LogAction("MoveToHob");
                MoveTo(Hob.transform.position);
                break;
            case AgentAction.MoveToPlate1:
                LogAction("MoveToPlate1");
                MoveTo(Plate1.transform.position);
                break;
            case AgentAction.MoveToPlate2:
                LogAction("MoveToPlate2");
                MoveTo(Plate2.transform.position);
                break;
            case AgentAction.PickUp:
                LogAction("PickUp/Drop");
                PerformPickup();
                break;
            case AgentAction.Chop:
                LogAction("Chop");
                ChopIngredient();
                break;
           // case AgentAction.Clean:
                //CleanDirtyPlates();
               // break;
           /* case AgentAction.Drop:
                DropItem();
                break;
           */
        }
    }
    private void LogAction(string action)
    {
        Debug.Log("Action: " + action);
        logFile.WriteLine(Time.time + ": " + action);
    }
    private void MoveTo(Vector3 destination)
    {
        if (navMeshAgent != null)
        {
            navMeshAgent.SetDestination(destination);
        }
    }

    private void ChopIngredient()
    {
        currentChoppingBoard.Interact(_playerController);
    }

    public void CleanDirtyPlates()
    {
        sink.Interact(_playerController);
    }

    public void PerformPickup()
    {
        var interactable = _interactableController.CurrentInteractable;

        if (_currentPickable == null)
        {
            _currentPickable = interactable as IPickable;
            if (_currentPickable != null)
            {
                animator.SetBool(_hasPickupHash, true);
                _currentPickable.Pick();
                _interactableController.Remove(_currentPickable as Interactable);

                // Ensure the object is not destroyed before setting its position
                if (_currentPickable != null && _currentPickable.gameObject != null)
                {
                    _currentPickable.gameObject.transform.SetPositionAndRotation(slot.transform.position, Quaternion.identity);
                    _currentPickable.gameObject.transform.SetParent(slot);
                }
                return;
            }

            _currentPickable = interactable?.TryToPickUpFromSlot(_currentPickable);
            if (_currentPickable != null)
            {
                animator.SetBool(_hasPickupHash, true);
            }

            // Ensure the object is not destroyed before setting its position
            if (_currentPickable != null && _currentPickable.gameObject != null)
            {
                _currentPickable.gameObject.transform.SetPositionAndRotation(slot.position, Quaternion.identity);
                _currentPickable.gameObject.transform.SetParent(slot);
            }
            return;
        }

        if (interactable == null || interactable is IPickable)
        {
            animator.SetBool(_hasPickupHash, false);

            // Ensure the object is not destroyed before calling Drop
            if (_currentPickable != null && _currentPickable.gameObject != null)
            {
                _currentPickable.Drop();
            }
            _currentPickable = null;
            return;
        }

        bool dropSuccess = interactable.TryToDropIntoSlot(_currentPickable);
        if (!dropSuccess) return;

        animator.SetBool(_hasPickupHash, false);
        _currentPickable = null;
    }
    public void DropItem()
    {
        if (_currentPickable != null)
        {
            Debug.Log($"Dropping item: {_currentPickable.gameObject.name}");
            _currentPickable.Drop();
            _currentPickable.gameObject.transform.SetParent(null);
            _currentPickable.gameObject.transform.position = transform.position + transform.forward * 0.5f;
            _currentPickable = null;

            if (animator != null)
            {
                animator.SetBool(_hasPickupHash, false);
            }

            Debug.Log("Item dropped.");
        }
        else
        {
            Debug.Log("No item to drop.");
        }
    }
}
