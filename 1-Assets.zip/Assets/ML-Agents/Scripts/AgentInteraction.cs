/*using UnityEngine;
public class AgentInteraction : MonoBehaviour
{
    private CookerAgent cookerAgent;

    private void Start()
    {
        cookerAgent = GetComponent<CookerAgent>();

        if (cookerAgent == null)
        {
            Debug.LogError("No CookerAgent script found on this GameObject!");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == cookerAgent.IngredientCrate_Tomato_01)
        {
            Debug.Log("Interacted with Tomato Crate!");
        }
        else if (other.gameObject == cookerAgent.IngredientCrate_Onion_01)
        {
            Debug.Log("Interacted with Onion Crate!");
        }
        else if (other.gameObject == cookerAgent.IngredientCrate_Mushroom_01)
        {
            Debug.Log("Interacted with Mushroom Crate!");
        }
    }
}
*/